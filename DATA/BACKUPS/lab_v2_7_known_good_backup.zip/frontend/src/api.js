// All requests use RELATIVE urls; the Vite dev server (or FastAPI in
// single-port mode) serves both the app and the API from the same origin.

const inflightGets = new Map();

async function req(path, opts = {}) {
  const method = (opts.method || "GET").toUpperCase();

  // Deduplicate and coalesce identical concurrent in-flight GET requests
  // to prevent browser HTTP/1.1 socket exhaustion (spec V2.9)
  if (method === "GET" && inflightGets.has(path)) {
    return inflightGets.get(path);
  }

  const execute = async () => {
    let controller = null;
    let timerId = null;
    let signal = opts.signal;

    if (!signal) {
      if (typeof AbortSignal !== "undefined" && typeof AbortSignal.timeout === "function") {
        signal = AbortSignal.timeout(8000);
      } else if (typeof AbortController !== "undefined") {
        controller = new AbortController();
        timerId = setTimeout(() => controller.abort(), 8000);
        signal = controller.signal;
      }
    }

    try {
      const res = await fetch(path, {
        headers: { "Content-Type": "application/json" },
        ...opts,
        signal,
        body: opts.body ? JSON.stringify(opts.body) : undefined,
      });
      if (!res.ok) {
        let detail = res.statusText;
        try { detail = (await res.json()).detail || detail; } catch {}
        throw new Error(`${res.status}: ${detail}`);
      }
      return await res.json();
    } finally {
      if (timerId) clearTimeout(timerId);
    }
  };

  if (method === "GET") {
    const promise = execute().finally(() => {
      inflightGets.delete(path);
    });
    inflightGets.set(path, promise);
    return promise;
  }

  return execute();
}

export const api = {
  status: () => req("/api/status"),
  labStatus: () => req("/api/lab/status"),
  labStart: (mode, target) => req("/api/lab/start", { method: "POST", body: { mode, target } }),
  labPause: () => req("/api/lab/pause", { method: "POST" }),
  labResume: () => req("/api/lab/resume", { method: "POST" }),
  labStop: () => req("/api/lab/stop", { method: "POST" }),
  labReset: () => req("/api/lab/reset", { method: "POST" }),
  labClearFailed: () => req("/api/lab/clear-failed", { method: "POST" }),
  recheck: () => req("/api/lab/recheck", { method: "POST" }),
  setTarget: (target) => req("/api/lab/target", { method: "POST", body: { target } }),
  getTarget: () => req("/api/lab/target"),

  population: (p = {}) => req(`/api/population?${new URLSearchParams(p)}`),
  scatter: (p = {}) => req(`/api/scatter?${new URLSearchParams(p)}`),
  tree: (p = {}) => req(`/api/tree?${new URLSearchParams(p)}`),
  strategy: (id) => req(`/api/strategies/${id}`),

  hypotheses: () => req("/api/hypotheses"),
  researchMemory: (p = {}) => req(`/api/research/memory?${new URLSearchParams(p)}`),
  applyHypothesis: (id) => req(`/api/hypotheses/${id}/apply`, { method: "POST" }),

  datasets: () => req("/api/data/datasets"),
  ingest: (body) => req("/api/data/ingest", { method: "POST", body }),
  bars: (id, limit = 300) => req(`/api/data/bars?dataset_id=${id}&limit=${limit}`),
  features: (id) => req(`/api/data/features?dataset_id=${id}`),
  ticks: (symbol, n = 1) => req(`/api/data/ticks?symbol=${symbol || ""}&n=${n}`),

  paperStatus: () => req("/api/paper/status"),
  paperStart: () => req("/api/paper/start", { method: "POST" }),
  paperStop: () => req("/api/paper/stop", { method: "POST" }),
  paperTrades: (limit = 150) => req(`/api/paper/trades?limit=${limit}`),
  executions: (limit = 150) => req(`/api/paper/executions?limit=${limit}`),
  calibration: () => req("/api/calibration"),
  recalibrate: () => req("/api/calibration/recalibrate", { method: "POST" }),

  risk: () => req("/api/risk"),
  killSwitch: (on) => req("/api/risk/kill-switch", { method: "POST", body: { on } }),
  realExecution: (enabled) =>
    req("/api/risk/real-execution", {
      method: "POST",
      body: { enabled, confirm: "ENABLE REAL TRADING" },
    }),

  settings: () => req("/api/settings"),
  applySettings: (body) => req("/api/settings", { method: "POST", body }),
  putSettings: (section, values) =>
    req(`/api/settings/${section}`, { method: "PUT", body: values }),

  jobs: (limit = 50) => req(`/api/jobs?limit=${limit}`),
  jobDetail: (id) => req(`/api/jobs/${id}`),
  dataInventory: () => req("/api/data/inventory"),
  diagnosticLog: (limit = 300) => req(`/api/logs/diagnostic?limit=${limit}`),
  researchShortlist: (params = {}) => req(`/api/research/shortlist?${new URLSearchParams(params)}`),
  researchFilter: (body) => req("/api/research/filter", { method: "POST", body }),
  strategyTrades: (sid) => req(`/api/strategies/${sid}/trades`),
  strategyRerunBacktest: (sid) => req(`/api/strategies/${sid}/backtest`, { method: "POST" }),
  strategyRunValidation: (sid) => req(`/api/strategies/${sid}/validate`, { method: "POST" }),
  savedShortlist: () => req("/api/research/shortlist/saved"),
  toggleShortlist: (sid, notes = "") => req("/api/research/shortlist/toggle", { method: "POST", body: { strategy_id: sid, notes } }),
  clearShortlist: () => req("/api/research/shortlist/clear", { method: "POST" }),

  logs: (limit = 500, level, category) =>
    req(`/api/logs?limit=${limit}${level ? `&level=${encodeURIComponent(level)}` : ""}${category ? `&category=${encodeURIComponent(category)}` : ""}`),
  exportLogs: () => req("/api/logs/export"),
  pipelineState: () => req("/api/pipeline/state"),
  events: (limit = 120) => req(`/api/events?limit=${limit}`),

  activity: (p = {}) => req(`/api/activity?${new URLSearchParams(p)}`),
  currentTask: () => req("/api/activity/current_task"),
  resources: () => req("/api/resources"),
  mt5Status: () => req("/api/mt5/status"),
  mt5Terminals: () => req("/api/mt5/terminals"),
  mt5Config: () => req("/api/mt5/config"),
  mt5Connect: (body = {}) => req("/api/mt5/connect", { method: "POST", body }),
  mt5Disconnect: () => req("/api/mt5/disconnect", { method: "POST" }),
  backup: () => req("/api/backup", { method: "POST" }),
  backups: () => req("/api/backups"),
  versions: () => req("/api/system/versions"),
  masterData: () => req("/api/data/master"),
  dataSync: (body) => req("/api/data/sync", { method: "POST", body }),
  systemStatusRow: () => req("/api/system/status_row"),
  workflowMilestones: () => req("/api/workflow/milestones"),
  workflowTaskState: () => req("/api/workflow/task_state"),
  featureTasks: (limit = 50) => req(`/api/features/tasks?limit=${limit}`),
  currentFeatureTask: () => req("/api/features/current_task"),
  featureStallCheck: () => req("/api/features/stall_check", { method: "POST" }),

  // Data Management endpoints (Spec V2.8 Step 4 & V2.9)
  dataManagementStatus: () => req("/api/data/management/status"),
  clearXauusdData: () => req("/api/data/clear/xauusd", { method: "POST", signal: AbortSignal.timeout(20000) }),
  clearCache: () => req("/api/data/clear/cache", { method: "POST", signal: AbortSignal.timeout(20000) }),
  clearNodes: () => req("/api/data/clear/nodes", { method: "POST", signal: AbortSignal.timeout(20000) }),
  clearGenomes: () => req("/api/data/clear/genomes", { method: "POST", signal: AbortSignal.timeout(20000) }),
  clearAllData: (confirm) => req("/api/data/clear/all", { method: "POST", body: { confirm }, signal: AbortSignal.timeout(25000) }),
};

export const fmt = {
  num: (v, d = 2) =>
    v == null || Number.isNaN(v) ? "–" : Number(v).toLocaleString(undefined, { maximumFractionDigits: d }),
  pct: (v, d = 1) => (v == null ? "–" : `${(v * 100).toFixed(d)}%`),
  ts: (t) => (t ? new Date(t * 1000).toLocaleTimeString() : "–"),
  dt: (t) => (t ? new Date(t * 1000).toLocaleString() : "–"),
  signed: (v, d = 2) => (v == null ? "–" : (v >= 0 ? "+" : "") + Number(v).toFixed(d)),
};
