import React, { useEffect, useState, useMemo } from "react";
import { api, fmt } from "../api.js";
import { useLab } from "../App.jsx";
import { Metric, Pill, EventFeed, SignedNum, ErrorNote } from "../components/common.jsx";

export default function Overview() {
  const { status, events, connected, refreshStatus, openStrategy } = useLab();
  const [top, setTop] = useState([]);
  const [resources, setResources] = useState(null);
  const [err, setErr] = useState(null);
  const [busy, setBusy] = useState("");
  const [sortCol, setSortCol] = useState("fitness");
  const [sortDir, setSortDir] = useState("desc");

  // V2.1 Total Node Target & Recheck State
  const [targetInput, setTargetInput] = useState("");
  const [recheckData, setRecheckData] = useState(null);
  const [rechecking, setRechecking] = useState(false);

  // V2.7 Data Inventory & Jobs State
  const [inventory, setInventory] = useState(null);
  const [jobsData, setJobsData] = useState(null);
  const [hwBusy, setHwBusy] = useState(false);

  // Minimum Trade Time & Post-Evaluation Filter State
  const [minTradeTimeInput, setMinTradeTimeInput] = useState("2");
  const [shortlistData, setShortlistData] = useState(null);
  const [shortlistLoading, setShortlistLoading] = useState(false);
  const [filterParams, setFilterParams] = useState({
    min_trades: 5,
    min_trade_duration_minutes: 2,
    min_return_pct: 0.0,
    max_drawdown_pct: 35.0,
    min_win_rate: 0.35,
    min_profit_factor: 1.0,
    stage: "",
  });

  const lab = status?.lab;
  const counts = status?.status_counts || {};

  // Sync targetInput with lab state initially or on update
  useEffect(() => {
    if (lab?.target && targetInput === "") {
      setTargetInput(String(lab.target));
    }
  }, [lab?.target]);

  const fetchShortlist = async (customParams) => {
    setShortlistLoading(true);
    try {
      const p = customParams || filterParams;
      const res = await api.researchFilter({
        ...p,
        min_trade_duration_seconds: Math.round((parseFloat(p.min_trade_duration_minutes) || 0) * 60),
      });
      setShortlistData(res);
    } catch (e) {
      console.error("Shortlist fetch failed", e);
    } finally {
      setShortlistLoading(false);
    }
  };

  const handleUpdateMinTradeTime = async (val) => {
    const mins = parseFloat(val);
    if (isNaN(mins) || mins < 0) return;
    try {
      const secs = Math.round(mins * 60);
      await api.applySettings({ min_trade_duration_seconds: secs });
      setMinTradeTimeInput(String(mins));
      setFilterParams((prev) => ({ ...prev, min_trade_duration_minutes: mins }));
      fetchShortlist({ ...filterParams, min_trade_duration_minutes: mins });
    } catch (e) {
      setErr("Failed to update min trade time: " + e.message);
    }
  };

  useEffect(() => {
    const fetchTop = () => {
      api.population({ limit: 40, sort: "fitness" })
        .then((r) => setTop(r.strategies || []))
        .catch((e) => setErr(e.message));
    };
    const fetchRes = () => {
      api.resources().then(setResources).catch(() => {});
    };
    const fetchInventory = () => {
      api.dataInventory().then(setInventory).catch(() => {});
    };
    const fetchJobs = () => {
      api.jobs().then(setJobsData).catch(() => {});
    };
    const fetchInitialSettings = () => {
      api.settings().then((s) => {
        if (s?.backtest?.min_trade_duration_seconds) {
          const m = s.backtest.min_trade_duration_seconds / 60.0;
          setMinTradeTimeInput(String(m));
          setFilterParams((prev) => ({ ...prev, min_trade_duration_minutes: m }));
        }
      }).catch(() => {});
    };

    fetchTop();
    fetchRes();
    fetchInventory();
    fetchJobs();
    fetchInitialSettings();
    fetchShortlist();

    let inFlightOverview = false;
    const t = setInterval(async () => {
      if (inFlightOverview) return;
      inFlightOverview = true;
      try {
        await Promise.all([
          api.population({ limit: 40, sort: "fitness" }).then((r) => setTop(r.strategies || [])).catch(() => {}),
          api.resources().then(setResources).catch(() => {}),
          api.dataInventory().then(setInventory).catch(() => {}),
          api.jobs().then(setJobsData).catch(() => {})
        ]);
      } finally {
        inFlightOverview = false;
      }
    }, 4000);
    return () => clearInterval(t);
  }, [events.length]);

  const handleToggleGpu = async () => {
    setHwBusy(true);
    try {
      const nextGpu = !resources?.gpu?.enabled;
      await api.applySettings({ gpu_enabled: nextGpu });
      const res = await api.resources();
      setResources(res);
      refreshStatus();
    } catch (e) {
      setErr("Failed to toggle GPU: " + e.message);
    } finally {
      setHwBusy(false);
    }
  };

  const handleSetCpuTarget = async (val) => {
    setHwBusy(true);
    try {
      await api.applySettings({ cpu_target_pct: val });
      const res = await api.resources();
      setResources(res);
      refreshStatus();
    } catch (e) {
      setErr("Failed to set CPU target: " + e.message);
    } finally {
      setHwBusy(false);
    }
  };

  const act = async (name, fn) => {
    setBusy(name);
    try { await fn(); } catch (e) { setErr(e.message); }
    setBusy("");
    setTimeout(refreshStatus, 400);
  };

  // V2.1 RECHECK: fast reconstruction from SQLite without rerun (spec §V2.1 G)
  const handleRecheck = async () => {
    setRechecking(true);
    setErr(null);
    try {
      const res = await api.recheck();
      setRecheckData(res);
      if (res.target) setTargetInput(String(res.target));
      refreshStatus();
    } catch (e) {
      setErr("Recheck failed: " + e.message);
    } finally {
      setRechecking(false);
    }
  };

  // V2.1 Set Total Node Target
  const handleUpdateTarget = async (newVal) => {
    const num = parseInt(newVal, 10);
    if (!num || num <= 0) return;
    try {
      const res = await api.setTarget(num);
      setRecheckData(res);
      setTargetInput(String(res.target));
      refreshStatus();
    } catch (e) {
      setErr("Failed to update target: " + e.message);
    }
  };

  // V2.1 START / CONTINUE EVOLUTION
  const handleStartContinue = async () => {
    const num = parseInt(targetInput, 10);
    const effTotal = recheckData?.total_nodes ?? lab?.total_nodes ?? 0;
    const effTarget = recheckData?.target ?? lab?.target ?? 500;
    if (effTotal >= effTarget && (!num || num <= effTotal)) {
      setErr(`Target of ${effTarget} is already reached (${effTotal}/${effTarget}). Enter a higher target (e.g. ${effTotal + 50}) to continue evolution.`);
      return;
    }
    setBusy("start");
    setErr(null);
    try {
      await api.labStart(lab?.mode || "continuous", num > effTarget ? num : undefined);
      setTimeout(refreshStatus, 400);
    } catch (e) {
      setErr(e.message);
    } finally {
      setBusy("");
    }
  };

  // Raw numeric sorting (spec §38)
  const handleSort = (col) => {
    if (sortCol === col) {
      setSortDir((prev) => (prev === "desc" ? "asc" : "desc"));
    } else {
      setSortCol(col);
      setSortDir("desc");
    }
  };

  const sortedTop = useMemo(() => {
    const list = [...top];
    list.sort((a, b) => {
      let va = a[sortCol];
      let vb = b[sortCol];
      if (sortCol === "dd") { va = a.dd; vb = b.dd; }
      if (sortCol === "return_pct") { va = a.return_pct; vb = b.return_pct; }
      if (va == null) va = -Infinity;
      if (vb == null) vb = -Infinity;
      return sortDir === "desc" ? (vb > va ? 1 : vb < va ? -1 : 0) : (va > vb ? 1 : va < vb ? -1 : 0);
    });
    return list.slice(0, 15);
  }, [top, sortCol, sortDir]);

  const sortArrow = (col) => {
    if (sortCol !== col) return "";
    return sortDir === "desc" ? " ↓" : " ↑";
  };

  // Derived V2.1 metrics
  const totalNodes = recheckData?.total_nodes ?? lab?.total_nodes ?? 0;
  const target = recheckData?.target ?? lab?.target ?? 500;
  const remaining = recheckData?.remaining ?? lab?.remaining ?? Math.max(0, target - totalNodes);
  const alive = recheckData?.alive ?? lab?.alive ?? 0;
  const dead = recheckData?.dead ?? lab?.dead ?? 0;
  const backtesting = recheckData?.backtesting ?? lab?.backtesting ?? (counts.BACKTESTING || 0);
  const validating = recheckData?.validating ?? lab?.validating ?? (counts.VALIDATING || 0);
  const qualified = recheckData?.qualified ?? lab?.qualified ?? ((counts.QUALIFIED || 0) + (counts.PAPER || 0));
  const currentGen = recheckData?.current_generation ?? lab?.generation ?? 0;
  const targetReached = totalNodes >= target;
  const progressPct = target > 0 ? Math.min(100, Math.round((totalNodes / target) * 1000) / 10) : 100;

  const cpu = resources?.cpu;
  const mem = resources?.memory;
  const gpu = resources?.gpu;
  const jobs = resources?.jobs;

  return (
    <div>
      <div className="flex justify-between items-center" style={{ marginBottom: "0.5rem" }}>
        <div>
          <h2 className="page-title">Overview</h2>
          <div className="page-sub">
            Autonomous evolutionary research laboratory · objective: robust positive expectancy.
          </div>
        </div>
      </div>

      <ErrorNote err={err} />

      {/* V2.1 TOTAL NODE TARGET & EVOLUTION CONTROL PANEL (spec §V2.1 D, G, H, I) */}
      <div className="panel" style={{
        marginBottom: 14,
        background: "linear-gradient(180deg, rgba(30, 41, 59, 0.7) 0%, rgba(15, 23, 42, 0.9) 100%)",
        border: "1px solid var(--border)",
        boxShadow: "0 4px 12px rgba(0,0,0,0.25)"
      }}>
        <div className="flex justify-between items-center" style={{ flexWrap: "wrap", gap: "10px", marginBottom: 12 }}>
          <div className="flex items-center" style={{ gap: "12px", flexWrap: "wrap" }}>
            <label style={{ fontSize: "0.85rem", fontWeight: 700, letterSpacing: "0.05em", color: "var(--fg)" }}>
              TOTAL NODE TARGET:
            </label>
            <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
              <input
                type="number"
                min="1"
                step="10"
                value={targetInput}
                onChange={(e) => setTargetInput(e.target.value)}
                onBlur={() => handleUpdateTarget(targetInput)}
                onKeyDown={(e) => { if (e.key === "Enter") handleUpdateTarget(targetInput); }}
                placeholder="e.g. 200"
                style={{
                  width: "100px",
                  padding: "6px 10px",
                  background: "var(--bg-box)",
                  border: "1px solid var(--border)",
                  borderRadius: "4px",
                  color: "var(--fg)",
                  fontWeight: "bold",
                  fontSize: "0.95rem",
                  fontFamily: "monospace",
                }}
              />
              <button
                className="btn"
                style={{ padding: "6px 10px", fontSize: "0.8rem" }}
                onClick={() => handleUpdateTarget(targetInput)}
              >
                SET TARGET
              </button>
            </div>

            <label style={{ fontSize: "0.85rem", fontWeight: 700, letterSpacing: "0.05em", color: "var(--fg)", marginLeft: "8px" }}>
              Minimum trade time (minutes):
            </label>
            <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
              <input
                type="number"
                min="0"
                step="0.5"
                value={minTradeTimeInput}
                onChange={(e) => setMinTradeTimeInput(e.target.value)}
                onBlur={() => handleUpdateMinTradeTime(minTradeTimeInput)}
                onKeyDown={(e) => { if (e.key === "Enter") handleUpdateMinTradeTime(minTradeTimeInput); }}
                placeholder="2"
                style={{
                  width: "70px",
                  padding: "6px 8px",
                  background: "var(--bg-box)",
                  border: "1px solid var(--border)",
                  borderRadius: "4px",
                  color: "var(--fg)",
                  fontWeight: "bold",
                  fontSize: "0.95rem",
                  fontFamily: "monospace",
                }}
              />
              <button
                className="btn"
                style={{ padding: "6px 10px", fontSize: "0.8rem" }}
                onClick={() => handleUpdateMinTradeTime(minTradeTimeInput)}
              >
                APPLY
              </button>
            </div>

            <button
              className="btn"
              style={{
                padding: "6px 16px",
                fontSize: "0.85rem",
                fontWeight: 700,
                background: "#334155",
                borderColor: "#475569",
                color: "#f8fafc"
              }}
              disabled={rechecking}
              onClick={handleRecheck}
            >
              {rechecking ? "🔄 RECHECKING..." : "🔄 RECHECK"}
            </button>

            <button
              className="btn primary"
              style={{
                padding: "6px 18px",
                fontSize: "0.85rem",
                fontWeight: 700,
                background: targetReached ? "#047857" : "var(--blue)",
              }}
              disabled={busy === "start"}
              onClick={handleStartContinue}
            >
              {lab?.running ? "▶ CONTINUE EVOLUTION" : "▶ START / CONTINUE EVOLUTION"}
            </button>

            {lab?.running && !lab?.paused && (
              <button className="btn" style={{ padding: "6px 12px" }} onClick={() => act("pause", api.labPause)}>
                ⏸ PAUSE
              </button>
            )}
            {lab?.running && lab?.paused && (
              <button className="btn" style={{ padding: "6px 12px" }} onClick={() => act("resume", api.labResume)}>
                ⏵ RESUME
              </button>
            )}
            {lab?.running && (
              <button className="btn danger" style={{ padding: "6px 12px" }} onClick={() => act("stop", api.labStop)}>
                ⏹ STOP
              </button>
            )}
          </div>

          <div style={{ fontSize: "0.8rem", color: "var(--muted)" }}>
            Ceiling Enforcement: <b style={{ color: "var(--green)" }}>STRICT BACKEND</b>
          </div>
        </div>

        {/* Target Reached Banner */}
        {targetReached && (
          <div style={{
            marginBottom: 12,
            padding: "8px 14px",
            borderRadius: "4px",
            background: "rgba(234, 179, 8, 0.15)",
            border: "1px solid rgba(234, 179, 8, 0.4)",
            color: "#fef08a",
            fontSize: "0.85rem",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            flexWrap: "wrap",
            gap: "8px"
          }}>
            <span>
              🎯 <b>NODE TARGET REACHED ({totalNodes} / {target})</b> — Evolution ceiling reached. All historical nodes and research are preserved. Increase target to continue.
            </span>
            <button
              className="btn"
              style={{ padding: "3px 8px", fontSize: "0.75rem", background: "rgba(0,0,0,0.3)" }}
              onClick={() => {
                const next = totalNodes + 100;
                setTargetInput(String(next));
                handleUpdateTarget(next);
              }}
            >
              +100 TARGET
            </button>
          </div>
        )}

        {/* Progress Bar (spec §V2.1 I) */}
        <div style={{ marginBottom: 12 }}>
          <div className="flex justify-between" style={{ fontSize: "0.75rem", marginBottom: 4 }}>
            <span className="muted">PROGRESS</span>
            <span className="mono font-bold" style={{ color: targetReached ? "var(--green)" : "var(--fg)" }}>
              {totalNodes} / {target} ({progressPct}%)
            </span>
          </div>
          <div style={{ height: "6px", background: "rgba(255,255,255,0.08)", borderRadius: "3px", overflow: "hidden" }}>
            <div style={{
              height: "100%",
              width: `${Math.min(100, progressPct)}%`,
              background: targetReached ? "linear-gradient(90deg, #10b981, #059669)" : "linear-gradient(90deg, #3b82f6, #06b6d4)",
              transition: "width 0.4s ease"
            }} />
          </div>
        </div>

        {/* 9 Display Metrics (spec §V2.1 I) */}
        <div className="grid cols-5" style={{ gap: "8px", gridTemplateColumns: "repeat(auto-fit, minmax(110px, 1fr))" }}>
          <div style={{ padding: "8px 10px", background: "var(--bg-box)", borderRadius: "4px", border: "1px solid rgba(255,255,255,0.05)" }}>
            <div className="muted" style={{ fontSize: "0.7rem", letterSpacing: "0.05em" }}>TOTAL NODES</div>
            <div style={{ fontSize: "1.25rem", fontWeight: 700, color: "var(--fg)", fontFamily: "monospace" }}>{totalNodes}</div>
            <div className="muted" style={{ fontSize: "0.68rem" }}>Historical count</div>
          </div>
          <div style={{ padding: "8px 10px", background: "var(--bg-box)", borderRadius: "4px", border: "1px solid rgba(255,255,255,0.05)" }}>
            <div className="muted" style={{ fontSize: "0.7rem", letterSpacing: "0.05em" }}>TARGET</div>
            <div style={{ fontSize: "1.25rem", fontWeight: 700, color: "var(--blue)", fontFamily: "monospace" }}>{target}</div>
            <div className="muted" style={{ fontSize: "0.68rem" }}>Max node ceiling</div>
          </div>
          <div style={{ padding: "8px 10px", background: "var(--bg-box)", borderRadius: "4px", border: "1px solid rgba(255,255,255,0.05)" }}>
            <div className="muted" style={{ fontSize: "0.7rem", letterSpacing: "0.05em" }}>REMAINING</div>
            <div style={{ fontSize: "1.25rem", fontWeight: 700, color: remaining > 0 ? "var(--green)" : "var(--muted)", fontFamily: "monospace" }}>{remaining}</div>
            <div className="muted" style={{ fontSize: "0.68rem" }}>Nodes allowed</div>
          </div>
          <div style={{ padding: "8px 10px", background: "var(--bg-box)", borderRadius: "4px", border: "1px solid rgba(255,255,255,0.05)" }}>
            <div className="muted" style={{ fontSize: "0.7rem", letterSpacing: "0.05em" }}>ALIVE</div>
            <div style={{ fontSize: "1.25rem", fontWeight: 700, color: "var(--green)", fontFamily: "monospace" }}>{alive}</div>
            <div className="muted" style={{ fontSize: "0.68rem" }}>Active / Survived</div>
          </div>
          <div style={{ padding: "8px 10px", background: "var(--bg-box)", borderRadius: "4px", border: "1px solid rgba(255,255,255,0.05)" }}>
            <div className="muted" style={{ fontSize: "0.7rem", letterSpacing: "0.05em" }}>DEAD</div>
            <div style={{ fontSize: "1.25rem", fontWeight: 700, color: "var(--red)", fontFamily: "monospace" }}>{dead}</div>
            <div className="muted" style={{ fontSize: "0.68rem" }}>Failed / Retired</div>
          </div>
          <div style={{ padding: "8px 10px", background: "var(--bg-box)", borderRadius: "4px", border: "1px solid rgba(255,255,255,0.05)" }}>
            <div className="muted" style={{ fontSize: "0.7rem", letterSpacing: "0.05em" }}>BACKTESTING</div>
            <div style={{ fontSize: "1.25rem", fontWeight: 700, color: backtesting > 0 ? "var(--blue)" : "var(--fg)", fontFamily: "monospace" }}>{backtesting}</div>
            <div className="muted" style={{ fontSize: "0.68rem" }}>In screen/detail</div>
          </div>
          <div style={{ padding: "8px 10px", background: "var(--bg-box)", borderRadius: "4px", border: "1px solid rgba(255,255,255,0.05)" }}>
            <div className="muted" style={{ fontSize: "0.7rem", letterSpacing: "0.05em" }}>VALIDATING</div>
            <div style={{ fontSize: "1.25rem", fontWeight: 700, color: validating > 0 ? "#a78bfa" : "var(--fg)", fontFamily: "monospace" }}>{validating}</div>
            <div className="muted" style={{ fontSize: "0.68rem" }}>In validation</div>
          </div>
          <div style={{ padding: "8px 10px", background: "var(--bg-box)", borderRadius: "4px", border: "1px solid rgba(255,255,255,0.05)" }}>
            <div className="muted" style={{ fontSize: "0.7rem", letterSpacing: "0.05em" }}>QUALIFIED</div>
            <div style={{ fontSize: "1.25rem", fontWeight: 700, color: "var(--green)", fontFamily: "monospace" }}>{qualified}</div>
            <div className="muted" style={{ fontSize: "0.68rem" }}>Robust survivors</div>
          </div>
          <div style={{ padding: "8px 10px", background: "var(--bg-box)", borderRadius: "4px", border: "1px solid rgba(255,255,255,0.05)" }}>
            <div className="muted" style={{ fontSize: "0.7rem", letterSpacing: "0.05em" }}>CURRENT GENERATION</div>
            <div style={{ fontSize: "1.25rem", fontWeight: 700, color: "var(--fg)", fontFamily: "monospace" }}>Gen {currentGen}</div>
            <div className="muted" style={{ fontSize: "0.68rem" }}>Highest gen</div>
          </div>
        </div>
      </div>

      {/* Mode Control Buttons */}
      <div className="btn-row" style={{ marginBottom: 14 }}>
        {["exploration", "evolution", "validation", "paper", "continuous"].map((m) => (
          <button key={m} className={"btn" + (lab?.mode === m && lab?.running ? " primary" : "")}
                  disabled={busy === "start"}
                  onClick={() => act("start", () => api.labStart(m))}>
            ▶ {m.toUpperCase()}
          </button>
        ))}
        <button className="btn" onClick={() => act("reset", api.labReset)}>↺ RESET GENERATION</button>
        <button className="btn" onClick={() => act("clear", api.labClearFailed)}>🧹 CLEAR FAILED</button>
      </div>

      {/* Resource Monitor Panel (spec §32, V2.7) */}
      <div className="panel" style={{ marginBottom: 14, background: "var(--bg-panel)", border: "1px solid var(--border)" }}>
        <div className="flex justify-between items-center" style={{ marginBottom: 10, flexWrap: "wrap", gap: "8px" }}>
          <div>
            <h3 style={{ margin: 0, fontSize: "0.95rem" }}>⚙ COMPUTATIONAL RESOURCE & ACCELERATION CONTROL (V2.71)</h3>
            <span className="muted" style={{ fontSize: "0.75rem" }}>
              Target CPU: <b>{cpu?.target_pct ?? 60}%</b> · Dynamic Worker Pool: <b style={{ color: "var(--green)" }}>{cpu?.effective_workers ?? 2} workers</b> · GPU: <b style={{ color: gpu?.enabled ? "var(--green)" : "var(--muted)" }}>{gpu?.enabled ? "ON" : "OFF"}</b>
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              className={`btn btn-xs ${gpu?.enabled ? "btn-primary" : "btn-subtle"}`}
              style={{ padding: "4px 10px", fontSize: "0.75rem", fontWeight: 700 }}
              disabled={hwBusy}
              onClick={handleToggleGpu}
            >
              GPU: {gpu?.enabled ? "ON (Accelerated)" : "OFF (CPU Only)"}
            </button>
          </div>
        </div>

        {/* Dynamic CPU Target 10%-100% Step Selector */}
        <div style={{
          marginBottom: 10,
          padding: "6px 10px",
          background: "rgba(0,0,0,0.25)",
          borderRadius: "4px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          flexWrap: "wrap",
          gap: "8px"
        }}>
          <span style={{ fontSize: "0.78rem", fontWeight: 700, color: "var(--fg-dim)" }}>
            CPU UTILIZATION TARGET (10%-100%):
          </span>
          <div className="flex gap-1" style={{ flexWrap: "wrap" }}>
            {[10, 20, 30, 40, 50, 60, 70, 80, 90, 100].map((pct) => (
              <button
                key={pct}
                disabled={hwBusy}
                onClick={() => handleSetCpuTarget(pct)}
                style={{
                  padding: "2px 6px",
                  fontSize: "0.72rem",
                  borderRadius: "3px",
                  border: "1px solid var(--border)",
                  background: (cpu?.target_pct === pct || (!cpu?.target_pct && pct === 60)) ? "var(--blue)" : "rgba(255,255,255,0.04)",
                  color: (cpu?.target_pct === pct || (!cpu?.target_pct && pct === 60)) ? "#fff" : "var(--fg-dim)",
                  fontWeight: (cpu?.target_pct === pct || (!cpu?.target_pct && pct === 60)) ? 800 : 500,
                  cursor: "pointer",
                }}
              >
                {pct}%
              </button>
            ))}
          </div>
        </div>

        <div className="grid cols-4" style={{ gap: "10px" }}>
          <div style={{ padding: "8px", background: "var(--bg-box)", borderRadius: "4px" }}>
            <div className="muted" style={{ fontSize: "0.75rem" }}>CPU UTILIZATION</div>
            <div style={{ fontSize: "1.2rem", fontWeight: 700, color: "var(--fg)" }}>{cpu?.percent ?? 0}%</div>
            <div className="muted" style={{ fontSize: "0.75rem" }}>Target: {cpu?.target_pct ?? 60}% · {cpu?.physical_cores} cores</div>
          </div>
          <div style={{ padding: "8px", background: "var(--bg-box)", borderRadius: "4px" }}>
            <div className="muted" style={{ fontSize: "0.75rem" }}>RAM USAGE / BUDGET</div>
            <div style={{ fontSize: "1.2rem", fontWeight: 700, color: (mem?.percent > 85 ? "var(--red)" : "var(--fg)") }}>
              {mem?.used_mb ? (mem.used_mb / 1024).toFixed(1) : "–"} GB
            </div>
            <div className="muted" style={{ fontSize: "0.75rem" }}>
              Budget: {mem?.limit_gb ?? "–"} GB ({mem?.value}{mem?.mode === "pct" ? "%" : "GB"})
            </div>
          </div>
          <div style={{ padding: "8px", background: "var(--bg-box)", borderRadius: "4px" }}>
            <div className="muted" style={{ fontSize: "0.75rem" }}>GPU ACCELERATION</div>
            <div style={{ fontSize: "1.2rem", fontWeight: 700, color: (gpu?.enabled && gpu?.available ? "var(--green)" : "var(--muted)") }}>
              {gpu?.enabled && gpu?.available ? `${gpu?.utilization_pct}%` : (gpu?.enabled ? "PROBING / CPU" : "OFF")}
            </div>
            <div className="muted" style={{ fontSize: "0.75rem" }}>
              {gpu?.name ? (gpu.name.length > 20 ? gpu.name.slice(0, 18) + "..." : gpu.name) : "CPU Fallback"}
            </div>
          </div>
          <div style={{ padding: "8px", background: "var(--bg-box)", borderRadius: "4px" }}>
            <div className="muted" style={{ fontSize: "0.75rem" }}>DYNAMIC WORKER POOL</div>
            <div style={{ fontSize: "1.2rem", fontWeight: 700, color: "var(--blue)" }}>
              {cpu?.active_workers ?? 0} active / {cpu?.effective_workers ?? 2} max
            </div>
            <div className="muted" style={{ fontSize: "0.75rem" }}>
              {jobs?.running ?? 0} running · {jobs?.queued ?? 0} queued
            </div>
          </div>
        </div>
      </div>

      {/* Real Multi-Level Progress & Stall Detection Widget (V2.7) */}
      {jobsData?.active_job && (
        <div className="panel" style={{
          marginBottom: 14,
          background: "linear-gradient(180deg, #182335 0%, #101826 100%)",
          border: `1px solid ${jobsData.active_job.is_stalled ? "#f59e0b" : "var(--border)"}`,
          boxShadow: "0 4px 12px rgba(0,0,0,0.3)"
        }}>
          <div className="flex justify-between items-center" style={{ marginBottom: 6 }}>
            <div className="flex items-center gap-2">
              <span style={{ fontWeight: 800, fontSize: "0.85rem", color: "var(--fg)" }}>
                ⚡ ACTIVE JOB: {jobsData.active_job.name}
              </span>
              <span className={`pill ${jobsData.active_job.is_stalled ? "neg" : (jobsData.active_job.status === "COMPLETED" ? "pos" : "sim")}`}
                    style={{ fontSize: "0.7rem", fontWeight: 800 }}>
                {jobsData.active_job.status}
              </span>
              {jobsData.active_job.is_stalled && (
                <span className="mono neg font-bold" style={{ fontSize: "0.75rem" }}>
                  ⚠ STALLED ({jobsData.active_job.stalled_duration_s}s inactive)
                </span>
              )}
            </div>
            <div className="mono" style={{ fontSize: "0.8rem" }}>
              <span className="muted">Elapsed: </span><b>{jobsData.active_job.elapsed_seconds}s</b>
              {jobsData.active_job.eta_seconds != null && (
                <> · <span className="muted">ETA: </span><b style={{ color: "var(--blue)" }}>{jobsData.active_job.eta_seconds}s</b></>
              )}
            </div>
          </div>

          <div style={{ height: "6px", background: "rgba(255,255,255,0.08)", borderRadius: "3px", overflow: "hidden", marginBottom: 8 }}>
            <div style={{
              height: "100%",
              width: `${jobsData.active_job.overall_progress_pct}%`,
              background: jobsData.active_job.is_stalled ? "#f59e0b" : "linear-gradient(90deg, #3b82f6, #10b981)",
              transition: "width 0.4s ease"
            }} />
          </div>

          {jobsData.active_job.stages?.length > 0 && (
            <div className="flex gap-2" style={{ flexWrap: "wrap", fontSize: "0.75rem" }}>
              {jobsData.active_job.stages.map((st) => (
                <div key={st.stage_id} style={{
                  padding: "3px 8px",
                  borderRadius: "3px",
                  background: "rgba(0,0,0,0.25)",
                  border: "1px solid rgba(255,255,255,0.06)"
                }}>
                  <span className="muted">{st.name}: </span>
                  <b style={{ color: st.status === "COMPLETED" ? "var(--green)" : "var(--fg)" }}>{st.progress_pct}%</b>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Top High-Level Metrics */}
      <div className="grid cols-4" style={{ marginBottom: 14 }}>
        <Metric label="Generation" value={currentGen} sub={`${lab?.cycle ?? 0} orchestrator cycles`} />
        <Metric label="Active population" value={lab?.population_active ?? "–"}
                sub={`target ${status?.config_summary?.population_size ?? "?"} · duplicates blocked ${lab?.duplicates_blocked ?? 0}`} />
        <Metric label="Qualified / Paper" value={`${counts.QUALIFIED || 0} / ${counts.PAPER || 0}`}
                sub={`validated ${lab?.counters?.validated ?? 0} · killed ${lab?.counters?.killed ?? 0}`} color="var(--green)" />
        <Metric label="Screened / Detailed" value={`${lab?.counters?.screened ?? 0} / ${lab?.counters?.detailed ?? 0}`}
                sub={`born ${lab?.counters?.born ?? 0} · hypotheses ${lab?.counters?.hypotheses ?? 0}`} />
      </div>

      {/* Top Strategies Table with Raw Numeric Sorting (spec §38) */}
      <div className="grid cols-2" style={{ gridTemplateColumns: "2fr 1.2fr", marginBottom: 14 }}>
        <div className="panel">
          <div className="flex justify-between items-center">
            <h3>Top strategies (sortable, click column header)</h3>
            <span className="muted" style={{ fontSize: "0.8rem" }}>Sorted by: <b>{sortCol}</b> ({sortDir})</span>
          </div>
          <div className="scroll-y" style={{ maxHeight: 330 }}>
            <table className="tbl">
              <thead>
                <tr>
                  <th onClick={() => handleSort("id")} style={{ cursor: "pointer" }}>id{sortArrow("id")}</th>
                  <th>status</th>
                  <th onClick={() => handleSort("generation")} style={{ cursor: "pointer" }}>gen{sortArrow("generation")}</th>
                  <th>tf</th>
                  <th onClick={() => handleSort("fitness")} style={{ cursor: "pointer" }}>fitness{sortArrow("fitness")}</th>
                  <th onClick={() => handleSort("pf")} style={{ cursor: "pointer" }}>PF{sortArrow("pf")}</th>
                  <th onClick={() => handleSort("return_pct")} style={{ cursor: "pointer" }}>return{sortArrow("return_pct")}</th>
                  <th onClick={() => handleSort("dd")} style={{ cursor: "pointer" }}>DD{sortArrow("dd")}</th>
                  <th onClick={() => handleSort("trades")} style={{ cursor: "pointer" }}>trades{sortArrow("trades")}</th>
                </tr>
              </thead>
              <tbody>
                {sortedTop.map((s) => (
                  <tr key={s.id} onClick={() => openStrategy(s.id)}>
                    <td className="mono">#{s.id}</td>
                    <td><Pill status={s.status} /></td>
                    <td>{s.generation}</td>
                    <td>{s.timeframe}</td>
                    <td className="mono font-bold">{fmt.num(s.fitness, 3)}</td>
                    <td className="mono">{fmt.num(s.pf, 2)}</td>
                    <td><SignedNum v={s.return_pct} pct /></td>
                    <td className="mono">{fmt.pct(s.dd)}</td>
                    <td>{s.trades ?? "–"}</td>
                  </tr>
                ))}
                {!sortedTop.length && <tr><td colSpan={9} className="muted">no tested strategies yet — press START</td></tr>}
              </tbody>
            </table>
          </div>
        </div>
        <div className="panel">
          <h3>Live event stream {connected ? <span className="pos">●</span> : <span className="neg">○</span>}</h3>
          <EventFeed events={events} limit={80} />
        </div>
      </div>

      <div className="grid cols-2" style={{ marginBottom: 14 }}>
        <div className="panel">
          <h3>Pipeline status counts</h3>
          <table className="tbl">
            <tbody>
              {Object.entries(counts).map(([k, v]) => (
                <tr key={k} style={{ cursor: "default" }}><td><Pill status={k} /></td><td>{v}</td></tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="panel">
          <h3>Component readiness (operational / simulated / pending)</h3>
          <div className="scroll-y" style={{ maxHeight: 260 }}>
            <table className="tbl">
              <tbody>
                {Object.entries(status?.components || {}).map(([k, v]) => (
                  <tr key={k} style={{ cursor: "default" }}>
                    <td className="mono">{k}</td>
                    <td className={v === "operational" ? "pos" : v.startsWith("PENDING") ? "neg" : "muted"}
                        style={{ fontSize: 11.5 }}>{v}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* V2.7 Persistent Data Architecture Inventory Panel */}
      <div className="panel" style={{
        marginBottom: 14,
        background: "linear-gradient(180deg, #131d2e 0%, #0e1624 100%)",
        border: "1px solid var(--border)",
        borderRadius: "6px",
      }}>
        <div className="flex justify-between items-center" style={{ marginBottom: 10, flexWrap: "wrap", gap: "8px" }}>
          <div>
            <h3 style={{ margin: 0, fontSize: "0.95rem" }}>🗄️ PERSISTENT DATA ARCHITECTURE INVENTORY (DATA_ROOT)</h3>
            <span className="muted" style={{ fontSize: "0.78rem" }}>
              Permanent Parquet storage · Incremental range sync · Stable schema versioning (<code className="mono">core_v1</code>) · Reusable cache
            </span>
          </div>

          <div className="flex items-center gap-2">
            <span className="pill pos" style={{ fontSize: "0.72rem", fontWeight: 700 }}>
              ✓ REUSE ENGINE ACTIVE
            </span>
          </div>
        </div>

        {/* Data Architecture Summary Metrics */}
        <div className="grid cols-4" style={{ gap: "8px", marginBottom: 12 }}>
          <div style={{ padding: "8px 10px", background: "var(--bg-box)", borderRadius: "4px" }}>
            <div className="muted" style={{ fontSize: "0.7rem" }}>DATASETS DISCOVERED</div>
            <div style={{ fontSize: "1.2rem", fontWeight: 700, color: "var(--fg)" }}>
              {inventory?.summary?.total_datasets ?? 0}
            </div>
            <div className="muted" style={{ fontSize: "0.68rem" }}>Permanent in DATA/MT5/raw/</div>
          </div>
          <div style={{ padding: "8px 10px", background: "var(--bg-box)", borderRadius: "4px" }}>
            <div className="muted" style={{ fontSize: "0.7rem" }}>TOTAL RAW BARS</div>
            <div style={{ fontSize: "1.2rem", fontWeight: 700, color: "var(--blue)" }}>
              {fmt.num(inventory?.summary?.total_raw_bars ?? 0, 0)}
            </div>
            <div className="muted" style={{ fontSize: "0.68rem" }}>Monotonic & integrity validated</div>
          </div>
          <div style={{ padding: "8px 10px", background: "var(--bg-box)", borderRadius: "4px" }}>
            <div className="muted" style={{ fontSize: "0.7rem" }}>CACHED FEATURE SETS</div>
            <div style={{ fontSize: "1.2rem", fontWeight: 700, color: "var(--green)" }}>
              {inventory?.summary?.total_features_cached ?? 0}
            </div>
            <div className="muted" style={{ fontSize: "0.68rem" }}>Persistent in DATA/features/</div>
          </div>
          <div style={{ padding: "8px 10px", background: "var(--bg-box)", borderRadius: "4px" }}>
            <div className="muted" style={{ fontSize: "0.7rem" }}>PERSISTED STORAGE</div>
            <div style={{ fontSize: "1.2rem", fontWeight: 700, color: "var(--fg)" }}>
              {inventory?.summary?.total_storage_mb ?? 0} MB
            </div>
            <div className="muted" style={{ fontSize: "0.68rem" }}>Relative portable paths</div>
          </div>
        </div>

        {/* Persisted Datasets Table */}
        <div className="scroll-y" style={{ maxHeight: 280 }}>
          <table className="tbl">
            <thead>
              <tr>
                <th>Symbol / TF</th>
                <th>Rows</th>
                <th>Stored Range (UTC)</th>
                <th>Source / Broker</th>
                <th>Feature Status</th>
                <th>Size</th>
                <th>Data Policy</th>
              </tr>
            </thead>
            <tbody>
              {(inventory?.datasets || []).map((d) => (
                <tr key={d.id} style={{ cursor: "default" }}>
                  <td className="mono font-bold" style={{ color: "var(--fg)" }}>
                    {d.symbol} <span className="pill" style={{ fontSize: "0.7rem", padding: "1px 4px" }}>{d.timeframe}</span>
                  </td>
                  <td className="mono">{fmt.num(d.rows, 0)}</td>
                  <td className="mono" style={{ fontSize: "0.75rem" }}>
                    {d.start_date} → {d.end_date}
                  </td>
                  <td>
                    <span className={`pill ${d.source === "SIMULATOR" ? "sim" : "real"}`} style={{ fontSize: "0.7rem" }}>
                      {d.source}
                    </span>{" "}
                    <span className="muted" style={{ fontSize: "0.75rem" }}>({d.broker})</span>
                  </td>
                  <td>
                    <span className="pill pos" style={{ fontSize: "0.7rem" }}>
                      {d.feature_status}
                    </span>
                  </td>
                  <td className="mono" style={{ fontSize: "0.75rem" }}>{d.size_mb} MB</td>
                  <td>
                    <span style={{
                      fontSize: "0.72rem",
                      fontWeight: 700,
                      color: "var(--green)",
                      background: "rgba(16, 185, 129, 0.12)",
                      padding: "2px 6px",
                      borderRadius: "3px",
                      border: "1px solid rgba(16, 185, 129, 0.25)"
                    }}>
                      REUSABLE · NO RE-FETCH
                    </span>
                  </td>
                </tr>
              ))}
              {(!inventory?.datasets || inventory.datasets.length === 0) && (
                <tr>
                  <td colSpan={7} className="muted" style={{ textAlign: "center", padding: "12px" }}>
                    No persisted datasets discovered in DATA/.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
