import React, { useEffect, useState } from "react";
import { api, fmt } from "../api.js";
import { useLab } from "../App.jsx";
import { Pill, SignedNum, ErrorNote, EventFeed, Metric } from "../components/common.jsx";

export default function PaperTrading() {
  const { events, openStrategy } = useLab();
  const [st, setSt] = useState(null);
  const [trades, setTrades] = useState({ trades: [], summary: {} });
  const [execs, setExecs] = useState([]);
  const [calib, setCalib] = useState(null);
  const [risk, setRisk] = useState(null);
  const [err, setErr] = useState(null);
  const [busy, setBusy] = useState("");

  const load = () => {
    api.paperStatus().then(setSt).catch((e) => setErr(e.message));
    api.paperTrades(120).then(setTrades).catch(() => {});
    api.executions(60).then((r) => setExecs(r.executions)).catch(() => {});
    api.calibration().then(setCalib).catch(() => {});
    api.risk().then(setRisk).catch(() => {});
  };
  useEffect(() => { load(); const t = setInterval(load, 5000); return () => clearInterval(t); }, []);

  const act = async (name, fn) => {
    setBusy(name);
    try { await fn(); load(); } catch (e) { setErr(e.message); }
    setBusy("");
  };

  const sum = trades.summary || {};

  return (
    <div>
      <h2 className="page-title">Paper Trading</h2>
      <div className="page-sub">
        Live-feed paper trading with realistic execution modeling. No real money — real execution
        requires explicit activation in Settings → Risk and a REAL MT5 bridge.
        Feed: <span className={"pill " + (st?.feed_is_simulated ? "sim" : "real")}>
          {st?.feed_source || "?"}</span>
      </div>
      <ErrorNote err={err} />

      <div className="btn-row">
        <button className="btn success" disabled={st?.running || busy === "start"}
                onClick={() => act("start", api.paperStart)}>▶ START PAPER TRADING</button>
        <button className="btn danger" disabled={!st?.running || busy === "stop"}
                onClick={() => act("stop", api.paperStop)}>⏹ STOP PAPER TRADING</button>
        <button className={"btn " + (risk?.kill_switch ? "success" : "danger")}
                onClick={() => act("kill", () => api.killSwitch(!risk?.kill_switch))}>
          {risk?.kill_switch ? "🔓 RELEASE KILL SWITCH" : "🛑 EMERGENCY KILL SWITCH"}
        </button>
        <button className="btn" onClick={() => act("recal", api.recalibrate)}>
          ⚖ RECALIBRATE execution model from observed stats
        </button>
      </div>

      <div className="grid cols-4" style={{ marginBottom: 14 }}>
        <Metric label="Engine" value={st?.running ? "RUNNING" : "STOPPED"}
                color={st?.running ? "var(--green)" : "var(--muted)"}
                sub={`signals ${st?.stats?.signals ?? 0} · orders ${st?.stats?.orders ?? 0} · rejections ${st?.stats?.rejections ?? 0}`} />
        <Metric label="Open positions" value={st?.open_positions?.length ?? 0}
                sub={`max allowed ${risk?.limits?.max_concurrent_positions ?? "?"}`} />
        <Metric label="Paper PnL (closed)" value={<SignedNum v={sum.pnl} />}
                sub={`${sum.open_n ?? 0} open · ${sum.n ?? 0} total trades`} />
        <Metric label="Observed execution"
                value={`${fmt.num(sum.slip, 2)} pt`}
                sub={`spread ${fmt.num(sum.spread, 1)} pt · delay ${fmt.num(sum.delay, 0)} ms`} />
      </div>

      <div className="grid cols-2" style={{ gridTemplateColumns: "1fr 1fr", marginBottom: 14 }}>
        <div className="panel">
          <h3>Enabled strategies (top qualified)</h3>
          <table className="tbl">
            <thead><tr><th>id</th><th>fitness</th><th>status</th><th>logic</th></tr></thead>
            <tbody>
              {(st?.enabled_strategies || []).map((s) => (
                <tr key={s.id} onClick={() => openStrategy(s.id)}>
                  <td>#{s.id}</td><td>{fmt.num(s.fitness, 3)}</td>
                  <td><Pill status={s.status} /></td>
                  <td className="mono muted" style={{ fontSize: 10.5 }}>{s.desc}</td>
                </tr>
              ))}
              {!st?.enabled_strategies?.length && (
                <tr><td colSpan={4} className="muted">
                  none yet — strategies must pass screening + detail + full validation
                  (OOS, walk-forward, stress, Monte Carlo) before paper trading.
                </td></tr>)}
            </tbody>
          </table>
          {st?.open_positions?.length > 0 && <>
            <h3 style={{ marginTop: 14 }}>Open positions</h3>
            <table className="tbl">
              <thead><tr><th>strategy</th><th>side</th><th>entry</th><th>lots</th><th>since</th><th>source</th></tr></thead>
              <tbody>{st.open_positions.map((p) => (
                <tr key={p.strategy_id} style={{ cursor: "default" }}>
                  <td onClick={() => openStrategy(p.strategy_id)}>#{p.strategy_id}</td>
                  <td className={p.side === "buy" ? "pos" : "neg"}>{p.side}</td>
                  <td>{fmt.num(p.entry_price)}</td><td>{p.lots}</td>
                  <td>{fmt.ts(p.entry_ts)}</td><td>{p.source}</td>
                </tr>))}
              </tbody>
            </table>
          </>}
        </div>

        <div className="panel">
          <h3>Live calibration — BACKTEST ASSUMPTION vs OBSERVED EXECUTION</h3>
          {calib && (
            <table className="tbl calib-tbl">
              <thead><tr><th>metric</th><th>backtest assumption</th><th>observed</th><th>Δ%</th><th>samples</th></tr></thead>
              <tbody>
                {(calib.assumption_vs_observed || []).map((r) => (
                  <tr key={r.metric} style={{ cursor: "default" }}>
                    <td>{r.metric}</td>
                    <td>{fmt.num(r.backtest_assumption, 2)}</td>
                    <td>{r.observed == null ? <span className="muted">no data</span> : fmt.num(r.observed, 2)}</td>
                    <td className={Math.abs(r.delta_pct || 0) > 40 ? "neg" : ""}>
                      {r.delta_pct == null ? "–" : `${r.delta_pct > 0 ? "+" : ""}${r.delta_pct}%`}</td>
                    <td>{r.samples}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
          <p className="muted" style={{ fontSize: 11.5, marginTop: 8 }}>{calib?.note}</p>

          {st?.divergence_flags?.length > 0 && (
            <div className="warn-banner">
              ⚠ Paper-vs-backtest divergence flags:{" "}
              {st.divergence_flags.map((f) => (
                <span key={f.strategy_id} style={{ marginRight: 10 }}>
                  #{f.strategy_id} (WR {fmt.pct(f.paper_win_rate, 0)} vs {fmt.pct(f.backtest_win_rate, 0)})
                </span>
              ))}
            </div>
          )}
          {risk?.recent_rejections?.length > 0 && (
            <div className="panel" style={{ marginTop: 8, background: "#2a1518" }}>
              <h3 style={{ color: "#fca5a5" }}>Recent risk-layer rejections</h3>
              {risk.recent_rejections.slice(-5).reverse().map((r, i) => (
                <div key={i} className="mono" style={{ fontSize: 11 }}>
                  {fmt.ts(r.ts)} #{r.strategy_id} {r.side} {r.symbol} — {r.reason}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="panel" style={{ marginBottom: 14 }}>
        <h3>Paper trades (full execution trail)</h3>
        <div className="scroll-y" style={{ maxHeight: 300 }}>
          <table className="tbl">
            <thead><tr>
              <th>#</th><th>strategy</th><th>side</th><th>signal</th><th>req px</th>
              <th>bid/ask</th><th>spread(pt)</th><th>exec</th><th>px</th><th>delay(ms)</th>
              <th>slip(pt)</th><th>exit</th><th>reason</th><th>PnL</th><th>status</th><th>source</th>
            </tr></thead>
            <tbody>
              {trades.trades.map((t) => (
                <tr key={t.id} style={{ cursor: "default" }}>
                  <td>{t.id}</td>
                  <td onClick={() => openStrategy(t.strategy_id)}>#{t.strategy_id}</td>
                  <td className={t.side === "buy" ? "pos" : "neg"}>{t.side}</td>
                  <td>{fmt.ts(t.signal_ts)}</td>
                  <td>{fmt.num(t.requested_price)}</td>
                  <td className="mono" style={{fontSize:10}}>{fmt.num(t.bid)}/{fmt.num(t.ask)}</td>
                  <td>{fmt.num(t.spread_points, 1)}</td>
                  <td>{fmt.ts(t.exec_ts)}</td>
                  <td>{fmt.num(t.exec_price)}</td>
                  <td>{fmt.num(t.exec_delay_ms, 0)}</td>
                  <td>{fmt.num(t.slippage_points, 1)}</td>
                  <td>{t.exit_price ? `${fmt.ts(t.exit_ts)} @ ${fmt.num(t.exit_price)}` : "–"}</td>
                  <td>{t.exit_reason || "–"}</td>
                  <td>{t.pnl == null ? "–" : <SignedNum v={t.pnl} />}</td>
                  <td><Pill status={t.status === "OPEN" ? "PAPER" : t.pnl > 0 ? "SURVIVED" : "FAILED"} /></td>
                  <td><span className={"pill " + (t.source === "SIMULATOR" ? "sim" : "real")}>{t.source}</span></td>
                </tr>
              ))}
              {!trades.trades.length && <tr><td colSpan={16} className="muted">no paper trades yet</td></tr>}
            </tbody>
          </table>
        </div>
      </div>

      <div className="grid cols-2">
        <div className="panel">
          <h3>Execution log (signal → risk → fill)</h3>
          <div className="scroll-y" style={{ maxHeight: 260 }}>
            <table className="tbl">
              <thead><tr><th>time</th><th>src</th><th>side</th><th>#strat</th><th>result</th><th>delay</th><th>slip</th><th>rejected_by</th></tr></thead>
              <tbody>{execs.map((e) => (
                <tr key={e.id} style={{ cursor: "default" }}>
                  <td>{fmt.ts(e.ts)}</td><td>{e.source}</td>
                  <td>{e.side}</td><td>{e.strategy_id ? `#${e.strategy_id}` : "–"}</td>
                  <td className={e.result === "FILLED" ? "pos" : "neg"}>{e.result}</td>
                  <td>{fmt.num(e.exec_delay_ms, 0)}</td><td>{fmt.num(e.slippage_points, 1)}</td>
                  <td className="muted" style={{fontSize:10}}>{e.rejected_by || ""}</td>
                </tr>))}
              </tbody>
            </table>
          </div>
        </div>
        <div className="panel">
          <h3>Paper events</h3>
          <EventFeed events={events} limit={40}
                     filter={(e) => e.type.startsWith("paper") || e.type === "kill_switch" || e.type === "recalibrated"} />
        </div>
      </div>
    </div>
  );
}
