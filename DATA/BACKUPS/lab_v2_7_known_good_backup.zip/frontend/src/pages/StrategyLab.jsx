import React, { useEffect, useState } from "react";
import { api, fmt } from "../api.js";
import { useLab } from "../App.jsx";
import { Pill, SignedNum, ErrorNote, JsonView } from "../components/common.jsx";

export default function StrategyLab() {
  const { openStrategy } = useLab();
  const [rows, setRows] = useState([]);
  const [counts, setCounts] = useState({});
  const [q, setQ] = useState("");
  const [statusF, setStatusF] = useState("");
  const [tfF, setTfF] = useState("");
  const [err, setErr] = useState(null);

  useEffect(() => {
    const load = () => api.population({ limit: 400, sort: "id", status: statusF || undefined,
                                         timeframe: tfF || undefined })
      .then((r) => { setRows(r.strategies || []); setCounts(r.status_counts || {}); })
      .catch((e) => setErr(e.message));
    load();
    const t = setInterval(load, 7000);
    return () => clearInterval(t);
  }, [statusF, tfF]);

  const filtered = rows.filter((s) =>
    !q || String(s.id).includes(q) ||
    (s.creation_reason || "").toLowerCase().includes(q.toLowerCase()) ||
    (s.species_key || "").toLowerCase().includes(q.toLowerCase()));

  return (
    <div>
      <h2 className="page-title">Strategy Laboratory</h2>
      <div className="page-sub">
        Every strategy is a node with full ancestry, genome, metrics and a research history
        explaining WHY it exists. Click any row for the complete dossier.
      </div>
      <ErrorNote err={err} />

      <div className="btn-row">
        <input placeholder="search id / reason / species" value={q} onChange={(e) => setQ(e.target.value)} style={{ width: 240 }} />
        <select value={statusF} onChange={(e) => setStatusF(e.target.value)}>
          <option value="">all statuses</option>
          {Object.keys(counts).map((s) => <option key={s}>{s} ({counts[s]})</option>)}
        </select>
        <select value={tfF} onChange={(e) => setTfF(e.target.value)}>
          <option value="">all timeframes</option>
          {["M1","M5","M15","M30","H1"].map((t) => <option key={t}>{t}</option>)}
        </select>
      </div>

      <div className="panel">
        <div className="scroll-y" style={{ maxHeight: "calc(100vh - 320px)" }}>
          <table className="tbl">
            <thead><tr>
              <th>id</th><th>status</th><th>gen</th><th>parent</th><th>sym</th><th>tf</th>
              <th>fitness</th><th>PF</th><th>return</th><th>DD</th><th>trades</th>
              <th>mutation</th><th>why it exists</th>
            </tr></thead>
            <tbody>
              {filtered.map((s) => (
                <tr key={s.id} onClick={() => openStrategy(s.id)}>
                  <td>#{s.id}</td>
                  <td><Pill status={s.status} /></td>
                  <td>{s.generation}</td>
                  <td>{s.parent_id ? `#${s.parent_id}` : "root"}</td>
                  <td>{s.symbol}</td>
                  <td>{s.timeframe}</td>
                  <td>{fmt.num(s.fitness, 3)}</td>
                  <td>{fmt.num(s.pf, 2)}</td>
                  <td><SignedNum v={s.return_pct} pct /></td>
                  <td>{fmt.pct(s.dd)}</td>
                  <td>{s.trades ?? "–"}</td>
                  <td className="muted" style={{ fontSize: 11 }}>{s.mutation_type || s.origin}</td>
                  <td className="muted" style={{ fontSize: 11, maxWidth: 340 }}>{s.creation_reason}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
