import React, { useEffect, useState } from "react";
import { api, fmt } from "../api.js";
import { MatrixTable, ErrorNote, Spinner, SignedNum } from "../components/common.jsx";

export default function BacktestMatrix() {
  const [candidates, setCandidates] = useState([]);
  const [sid, setSid] = useState("");
  const [detail, setDetail] = useState(null);
  const [err, setErr] = useState(null);

  useEffect(() => {
    api.population({ limit: 60, sort: "fitness" })
      .then((r) => {
        setCandidates(r.strategies || []);
        if (!sid && r.strategies?.length) {
          const q = (r.strategies.find((s) => ["QUALIFIED", "PAPER", "VALIDATING", "SURVIVED"].includes(s.status))
                     || r.strategies[0]);
          setSid(String(q.id));
        }
      })
      .catch((e) => setErr(e.message));
  }, []);

  useEffect(() => {
    if (!sid) return;
    setDetail(null);
    api.strategy(sid).then(setDetail).catch((e) => setErr(e.message));
  }, [sid]);

  const mats = detail?.matrices;
  const detailBt = detail?.backtests?.find((b) => b.stage === "detail");
  const m = detailBt?.metrics || {};

  return (
    <div>
      <h2 className="page-title">Backtest Matrix</h2>
      <div className="page-sub">
        Diagnostic matrices per strategy: TIMEFRAME (genome re-run on each timeframe), SESSION, DAY,
        REGIME and DIRECTION (grouped from realized trades). Losing dimensions trigger specialized
        children — never silent deletion.
      </div>
      <ErrorNote err={err} />

      <div className="btn-row">
        <select value={sid} onChange={(e) => setSid(e.target.value)} style={{ minWidth: 320 }}>
          {candidates.map((c) => (
            <option key={c.id} value={c.id}>
              #{c.id} · {c.status} · {c.timeframe} · fit {fmt.num(c.fitness, 3)}
            </option>
          ))}
        </select>
        {detail && <span className="muted">{detail.strategy.description}</span>}
      </div>

      {!detail && <Spinner />}
      {detail && (
        <>
          <div className="grid cols-4" style={{ marginBottom: 14 }}>
            {[["Trades", m.trades], ["Net PnL", <SignedNum v={m.net_profit} />],
              ["PF", fmt.num(m.profit_factor, 2)], ["Max DD", fmt.pct(m.max_drawdown_pct)],
              ["Return", <SignedNum v={m.total_return_pct} pct />],
              ["Sharpe", fmt.num(m.sharpe, 2)], ["Win rate", fmt.pct(m.win_rate)],
              ["Spread cost", fmt.num(m.total_spread_cost)]].map(([l, v]) => (
              <div className="panel metric-card" key={l}>
                <div className="label">{l}</div><div className="value" style={{ fontSize: 16 }}>{v ?? "–"}</div>
              </div>
            ))}
          </div>

          {!mats && (
            <div className="panel">
              <p className="muted">
                Matrices for this strategy have not been computed yet. They are generated automatically
                when a strategy reaches QUALIFIED (specialization pass). Screening/detail metrics above
                are already available.
              </p>
            </div>
          )}
          {mats && (
            <div className="grid cols-2">
              <div>
                <MatrixTable title="TIMEFRAME" data={mats.timeframe}
                             valueKeys={["trades", "profit", "pf", "dd", "return_pct", "sharpe", "fitness", "error"]} />
                <MatrixTable title="SESSION" data={mats.session} />
                <MatrixTable title="DAY" data={mats.day} />
              </div>
              <div>
                <MatrixTable title="REGIME" data={mats.regime} />
                <MatrixTable title="DIRECTION" data={mats.direction} />
                {detail.validation && (
                  <div className="panel">
                    <h3>Validation summary</h3>
                    <div className="mono" style={{ fontSize: 12 }}>
                      robustness {fmt.num(detail.validation.robustness_score, 3)} ·
                      passed: {detail.validation.passed ? "YES" : "NO"} ·
                      OOS degradation {fmt.pct(detail.validation.oos?.degradation)} ·
                      WF positive folds {detail.validation.walkforward?.positive_folds}/{detail.validation.walkforward?.n_folds} ·
                      MC positive {fmt.pct(detail.validation.montecarlo?.return_positive_frac, 0)} ·
                      worst stress degradation {fmt.pct(detail.validation.spread_stress?.worst_degradation)}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
