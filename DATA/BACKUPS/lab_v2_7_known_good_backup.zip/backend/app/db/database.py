"""
SQLite persistence layer for lab state: strategies (genomes + ancestry),
backtests, validations, paper trades, execution stats, hypotheses, events.

Large market/feature datasets live in Parquet (see app/data/storage.py) and
can be queried with DuckDB; this DB holds metadata & research state only.
"""
from __future__ import annotations

import json
import sqlite3
import threading
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

SCHEMA = """
CREATE TABLE IF NOT EXISTS strategies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    hash TEXT UNIQUE NOT NULL,
    parent_id INTEGER,
    generation INTEGER NOT NULL DEFAULT 0,
    symbol TEXT NOT NULL,
    timeframe TEXT NOT NULL,
    direction TEXT NOT NULL DEFAULT 'both',
    status TEXT NOT NULL DEFAULT 'BORN',
    creation_reason TEXT,
    mutation_type TEXT,
    species_key TEXT,
    genome TEXT NOT NULL,
    complexity INTEGER NOT NULL DEFAULT 0,
    fitness REAL,
    created_at REAL NOT NULL,
    updated_at REAL NOT NULL,
    origin TEXT NOT NULL DEFAULT 'seed',
    hypothesis_id INTEGER,
    run_id TEXT
);
CREATE INDEX IF NOT EXISTS idx_strategies_status ON strategies(status);
CREATE INDEX IF NOT EXISTS idx_strategies_gen ON strategies(generation);
CREATE INDEX IF NOT EXISTS idx_strategies_fitness ON strategies(fitness);
CREATE INDEX IF NOT EXISTS idx_strategies_parent ON strategies(parent_id);
CREATE INDEX IF NOT EXISTS idx_strategies_run ON strategies(run_id);

CREATE TABLE IF NOT EXISTS backtests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    strategy_id INTEGER NOT NULL,
    stage TEXT NOT NULL,            -- screen | detail | oos | walkforward | stress | perturbation | montecarlo | matrix
    dataset_id TEXT NOT NULL,
    window TEXT,                    -- json: {start,end,tag}
    params TEXT,                    -- json: stress/perturbation params if any
    metrics TEXT NOT NULL,          -- json blob
    fitness REAL,
    verdict TEXT,
    created_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_bt_strategy ON backtests(strategy_id);

CREATE TABLE IF NOT EXISTS validations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    strategy_id INTEGER NOT NULL UNIQUE,
    oos TEXT, walkforward TEXT, perturbation TEXT,
    spread_stress TEXT, slippage_stress TEXT, montecarlo TEXT,
    regime_holdout TEXT,
    robustness_score REAL,
    passed INTEGER,
    notes TEXT,
    created_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS matrices (
    strategy_id INTEGER NOT NULL PRIMARY KEY,
    timeframe TEXT, session TEXT, day TEXT, regime TEXT, direction TEXT,
    created_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS paper_trades (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    strategy_id INTEGER NOT NULL,
    symbol TEXT NOT NULL,
    side TEXT NOT NULL,
    signal_ts REAL NOT NULL,
    requested_price REAL,
    bid REAL, ask REAL, spread_points REAL,
    exec_ts REAL, exec_price REAL,
    exec_delay_ms REAL, slippage_points REAL,
    exit_ts REAL, exit_price REAL, exit_reason TEXT,
    lots REAL, pnl REAL, status TEXT NOT NULL DEFAULT 'OPEN',
    regime TEXT, genome_hash TEXT, source TEXT NOT NULL DEFAULT 'SIMULATOR',
    notes TEXT
);
CREATE INDEX IF NOT EXISTS idx_pt_strategy ON paper_trades(strategy_id);

CREATE TABLE IF NOT EXISTS executions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts REAL NOT NULL, source TEXT NOT NULL,   -- SIMULATOR | MT5_DEMO | MT5_LIVE
    symbol TEXT, side TEXT, strategy_id INTEGER,
    requested_price REAL, bid REAL, ask REAL, spread_points REAL,
    signal_ts REAL, exec_ts REAL, exec_delay_ms REAL,
    slippage_points REAL, result TEXT, rejected_by TEXT
);

CREATE TABLE IF NOT EXISTS hypotheses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    strategy_id INTEGER,
    source TEXT NOT NULL DEFAULT 'rule_analyzer',  -- rule_analyzer | llm
    observation TEXT NOT NULL,
    hypothesis TEXT NOT NULL,
    proposal TEXT NOT NULL,     -- json: genome mutation proposal
    status TEXT NOT NULL DEFAULT 'PROPOSED',   -- PROPOSED | APPLIED | REJECTED
    child_strategy_id INTEGER,
    created_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts REAL NOT NULL,
    type TEXT NOT NULL,
    payload TEXT
);

CREATE TABLE IF NOT EXISTS datasets (
    id TEXT PRIMARY KEY,
    symbol TEXT NOT NULL, timeframe TEXT NOT NULL,
    start_ts REAL, end_ts REAL, bars INTEGER,
    source TEXT NOT NULL,   -- SIMULATOR | MT5
    path TEXT NOT NULL,
    feature_cache TEXT,     -- json list of cached feature specs
    created_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS calibration (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts REAL NOT NULL, source TEXT NOT NULL, symbol TEXT NOT NULL,
    metric TEXT NOT NULL, backtest_assumption REAL, observed REAL,
    samples INTEGER, notes TEXT
);

CREATE TABLE IF NOT EXISTS generation_stats (
    generation INTEGER PRIMARY KEY,
    born INTEGER, tested INTEGER, failed INTEGER, survived INTEGER,
    validated INTEGER, qualified INTEGER, killed INTEGER, retired INTEGER,
    duplicates_blocked INTEGER, best_fitness REAL, avg_fitness REAL,
    ts REAL
);
"""


class Database:
    def __init__(self, path: str):
        self.path = path
        self._lock = threading.RLock()
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        with self._lock:
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA synchronous=NORMAL")
            # Ensure run_id column exists in existing strategies table before SCHEMA executes indexes
            tables = [r[0] for r in self._conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='strategies'").fetchall()]
            if tables:
                cols = [col[1] for col in self._conn.execute("PRAGMA table_info(strategies)").fetchall()]
                if "run_id" not in cols:
                    self._conn.execute("ALTER TABLE strategies ADD COLUMN run_id TEXT")
                    self._conn.commit()
            self._conn.executescript(SCHEMA)
            self._conn.commit()
            # V2: safe schema migration (preserves every V1 row; on failure
            # raises MigrationError and writes LOGS/migration_error.log)
            from .migrations import migrate
            migrate(self._conn, SCHEMA)

    @property
    def conn(self) -> sqlite3.Connection:
        return self._conn

    # ---------- meta key/value ----------
    def get_meta(self, key: str, default=None):
        row = self.one("SELECT value FROM meta WHERE key=?", (key,))
        return row["value"] if row else default

    def set_meta(self, key: str, value: str) -> None:
        self.x("INSERT OR REPLACE INTO meta (key,value) VALUES (?,?)", (key, value))

    def close(self) -> None:
        with self._lock:
            try:
                self._conn.close()
            except Exception:
                pass

    # ---------- helpers ----------
    def q(self, sql: str, args: tuple = ()) -> List[Dict[str, Any]]:
        with self._lock:
            cur = self._conn.execute(sql, args)
            rows = [dict(r) for r in cur.fetchall()]
        return rows

    def one(self, sql: str, args: tuple = ()) -> Optional[Dict[str, Any]]:
        rows = self.q(sql, args)
        return rows[0] if rows else None

    def x(self, sql: str, args: tuple = ()) -> int:
        with self._lock:
            cur = self._conn.execute(sql, args)
            self._conn.commit()
            return cur.lastrowid or cur.rowcount

    def xm(self, sql: str, seq: List[tuple]) -> None:
        with self._lock:
            self._conn.executemany(sql, seq)
            self._conn.commit()

    # ---------- strategies ----------
    def insert_strategy(self, s: Dict[str, Any]) -> Optional[int]:
        now = time.time()
        try:
            return self.x(
                """INSERT INTO strategies
                   (hash,parent_id,generation,symbol,timeframe,direction,status,
                    creation_reason,mutation_type,species_key,genome,complexity,
                    fitness,created_at,updated_at,origin,hypothesis_id,run_id)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (s["hash"], s.get("parent_id"), s.get("generation", 0), s["symbol"],
                 s["timeframe"], s.get("direction", "both"), s.get("status", "BORN"),
                 s.get("creation_reason"), s.get("mutation_type"), s.get("species_key"),
                 json.dumps(s["genome"]), s.get("complexity", 0), s.get("fitness"),
                 now, now, s.get("origin", "seed"), s.get("hypothesis_id"),
                 s.get("run_id")),
            )
        except sqlite3.IntegrityError:
            # duplicate genome hash -> caller handles dedupe
            return None

    def find_by_hash(self, h: str) -> Optional[Dict[str, Any]]:
        return self.one("SELECT * FROM strategies WHERE hash=?", (h,))

    def update_strategy(self, sid: int, **fields: Any) -> None:
        if not fields:
            return
        fields["updated_at"] = time.time()
        sets = ",".join(f"{k}=?" for k in fields)
        self.x(f"UPDATE strategies SET {sets} WHERE id=?", tuple(fields.values()) + (sid,))

    def get_strategy(self, sid: int) -> Optional[Dict[str, Any]]:
        row = self.one("SELECT * FROM strategies WHERE id=?", (sid,))
        if row:
            row["genome"] = json.loads(row["genome"])
        return row

    def count_by_status(self, run_id: Optional[str] = None) -> Dict[str, int]:
        if run_id:
            rows = self.q("SELECT status, COUNT(*) c FROM strategies WHERE run_id=? GROUP BY status", (run_id,))
        else:
            rows = self.q("SELECT status, COUNT(*) c FROM strategies GROUP BY status")
        return {r["status"]: r["c"] for r in rows}

    def get_shortlist(self) -> List[int]:
        self.x("""CREATE TABLE IF NOT EXISTS research_shortlist (
            strategy_id INTEGER PRIMARY KEY,
            notes TEXT,
            created_at REAL NOT NULL
        )""")
        rows = self.q("SELECT strategy_id FROM research_shortlist ORDER BY created_at DESC")
        return [int(r["strategy_id"]) for r in rows]

    def add_to_shortlist(self, strategy_id: int, notes: str = "") -> None:
        self.x("""CREATE TABLE IF NOT EXISTS research_shortlist (
            strategy_id INTEGER PRIMARY KEY,
            notes TEXT,
            created_at REAL NOT NULL
        )""")
        self.x("INSERT OR REPLACE INTO research_shortlist (strategy_id, notes, created_at) VALUES (?,?,?)",
               (strategy_id, notes, time.time()))

    def remove_from_shortlist(self, strategy_id: int) -> None:
        self.x("""CREATE TABLE IF NOT EXISTS research_shortlist (
            strategy_id INTEGER PRIMARY KEY,
            notes TEXT,
            created_at REAL NOT NULL
        )""")
        self.x("DELETE FROM research_shortlist WHERE strategy_id=?", (strategy_id,))

    def clear_shortlist(self) -> None:
        self.x("""CREATE TABLE IF NOT EXISTS research_shortlist (
            strategy_id INTEGER PRIMARY KEY,
            notes TEXT,
            created_at REAL NOT NULL
        )""")
        self.x("DELETE FROM research_shortlist")

    def total_strategies_count(self, run_id: Optional[str] = None) -> int:
        if run_id:
            row = self.one("SELECT COUNT(*) c FROM strategies WHERE run_id=?", (run_id,))
        else:
            row = self.one("SELECT COUNT(*) c FROM strategies")
        return int(row["c"]) if row else 0

    def max_strategy_id(self) -> int:
        row = self.one("SELECT COALESCE(MAX(id), 0) m FROM strategies")
        return int(row["m"]) if row else 0

    def next_strategy_id(self) -> int:
        return self.max_strategy_id() + 1

    def reconstruct_state(self, total_node_target: int = 500) -> Dict[str, Any]:
        """Fast state reconstruction from persisted SQLite database and disk (spec §V2.1 G)."""
        counts = self.count_by_status()
        total_nodes = self.total_strategies_count()
        next_id = self.next_strategy_id()
        gen_row = self.one("SELECT COALESCE(MAX(generation), 0) g FROM strategies")
        current_gen = int(gen_row["g"]) if gen_row else 0

        # ALIVE: BORN, BACKTESTING, SURVIVED, VALIDATING, PAPER, QUALIFIED
        alive_statuses = ("BORN", "BACKTESTING", "SURVIVED", "VALIDATING", "PAPER", "QUALIFIED")
        alive = sum(counts.get(s, 0) for s in alive_statuses)

        # DEAD: FAILED, KILLED, RETIRED
        dead_statuses = ("FAILED", "KILLED", "RETIRED")
        dead = sum(counts.get(s, 0) for s in dead_statuses)

        backtesting = counts.get("BACKTESTING", 0)
        validating = counts.get("VALIDATING", 0)
        qualified = counts.get("QUALIFIED", 0) + counts.get("PAPER", 0)

        target = max(1, int(total_node_target))
        remaining = max(0, target - total_nodes)
        target_reached = total_nodes >= target

        # Ancestry metrics
        edges_row = self.one("SELECT COUNT(*) e FROM strategies WHERE parent_id IS NOT NULL")
        roots_row = self.one("SELECT COUNT(*) r FROM strategies WHERE parent_id IS NULL")

        # Fingerprints metrics
        has_bt = self.one("SELECT name FROM sqlite_master WHERE type='table' AND name='backtests'")
        if has_bt:
            bt_cnt = self.one("""SELECT COUNT(*) c,
                                        COUNT(CASE WHEN fingerprint IS NOT NULL AND fingerprint != '' THEN 1 END) fp,
                                        COUNT(CASE WHEN stale=1 THEN 1 END) st
                                 FROM backtests""")
        else:
            bt_cnt = {"c": 0, "fp": 0, "st": 0}

        has_val = self.one("SELECT name FROM sqlite_master WHERE type='table' AND name='validations'")
        if has_val:
            val_cnt = self.one("""SELECT COUNT(*) c,
                                         COUNT(CASE WHEN fingerprint IS NOT NULL AND fingerprint != '' THEN 1 END) fp
                                  FROM validations""")
        else:
            val_cnt = {"c": 0, "fp": 0}

        # Research files on disk
        from ..paths import RESEARCH_DIR
        def safe_file_count(p):
            try:
                return len(list(p.glob("*"))) if p.exists() else 0
            except Exception:
                return 0

        research_state = {
            "strategies_exported": safe_file_count(RESEARCH_DIR / "strategies"),
            "generations_exported": safe_file_count(RESEARCH_DIR / "generations"),
            "backtests_exported": safe_file_count(RESEARCH_DIR / "backtests"),
            "validations_exported": safe_file_count(RESEARCH_DIR / "validations"),
        }

        # Datasets metrics
        has_ds = self.one("SELECT name FROM sqlite_master WHERE type='table' AND name='datasets'")
        ds_row = self.one("SELECT COUNT(*) c FROM datasets") if has_ds else {"c": 0}

        eval_row = self.one("SELECT COUNT(DISTINCT strategy_id) e FROM backtests")
        bt_stage_row = self.one("SELECT COUNT(*) b FROM backtests WHERE stage IN ('screen', 'detail')")
        node_accounting = {
            "total_created": total_nodes,
            "total_evaluated": int(eval_row["e"]) if eval_row else 0,
            "total_backtested": int(bt_stage_row["b"]) if bt_stage_row else 0,
            "total_validated": int(val_cnt.get("c", 0)),
            "total_qualified": qualified,
            "total_rejected": counts.get("FAILED", 0) + counts.get("KILLED", 0),
            "total_dead": dead,
            "total_active": counts.get("BORN", 0) + backtesting + counts.get("SURVIVED", 0) + validating,
            "total_remaining": remaining,
        }

        return {
            "total_nodes": total_nodes,
            "target": target,
            "remaining": remaining,
            "alive": alive,
            "dead": dead,
            "backtesting": backtesting,
            "validating": validating,
            "qualified": qualified,
            "node_accounting": node_accounting,
            "current_generation": current_gen,
            "next_strategy_id": next_id,
            "target_reached": target_reached,
            "progress": f"{total_nodes} / {target}",
            "progress_pct": round((total_nodes / target) * 100, 1) if target > 0 else 100.0,
            "status_counts": counts,
            "ancestry": {
                "total_edges": int(edges_row["e"]) if edges_row else 0,
                "root_nodes": int(roots_row["r"]) if roots_row else 0,
                "max_depth": current_gen,
            },
            "fingerprints": {
                "backtests_total": int(bt_cnt["c"]) if bt_cnt else 0,
                "backtests_fingerprinted": int(bt_cnt["fp"]) if bt_cnt else 0,
                "backtests_stale": int(bt_cnt["st"]) if bt_cnt else 0,
                "validations_total": int(val_cnt["c"]) if val_cnt else 0,
                "validations_fingerprinted": int(val_cnt["fp"]) if val_cnt else 0,
            },
            "research": research_state,
            "evolution_seed": self.get_meta("evolution_seed") or "20250925",
            "datasets_count": int(ds_row["c"]) if ds_row else 0,
        }

    def log_event(self, etype: str, payload: Dict[str, Any]) -> int:
        from ..jsonutil import jd
        return self.x("INSERT INTO events (ts,type,payload) VALUES (?,?,?)",
                      (time.time(), etype, jd(payload)))


_db: Optional[Database] = None


def get_db(path: str | None = None) -> Database:
    global _db
    if _db is not None:
        try:
            _db._conn.execute("SELECT 1")
        except (sqlite3.ProgrammingError, sqlite3.OperationalError):
            _db = None
    if _db is None:
        from ..config import get_config
        _db = Database(path or get_config().database_path)
    return _db
