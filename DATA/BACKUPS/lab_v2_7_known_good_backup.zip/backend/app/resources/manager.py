"""
Computational Resource Enforcement & Monitoring (spec §26, §27, §28, §29, §30, §31, §32).

Actual computational limits (not cosmetic):
  - CPU worker limiting for ProcessPool
  - Dynamic memory budget check before scheduling heavy batches
  - GPU initialization guard with safe CPU fallback (spec §31)
  - Live system metrics (CPU %, RAM used/limit, GPU/VRAM, active workers)
"""
from __future__ import annotations

import logging
import os
import shutil
import subprocess
import threading
import time
from typing import Any, Dict, Optional

import psutil

from ..activity import activity
from ..config import get_config

log = logging.getLogger("resources.manager")


class ResourceManager:
    def __init__(self):
        self._lock = threading.RLock()
        self._gpu_checked = False
        self._gpu_available = False
        self._gpu_name = "None"
        self._gpu_vram_total_mb = 0.0
        self._gpu_vram_used_mb = 0.0
        self._gpu_utilization_pct = 0.0
        self._active_workers = 0
        self._queued_jobs = 0
        self._running_jobs = 0

    # ---------- CPU & Worker limits (spec §27, V2.7) ----------
    def effective_workers(self) -> int:
        """Enforces configured CPU target utilization (10%-100%) and dynamically sizes worker pool."""
        cfg = get_config()
        cores = os.cpu_count() or 2
        target_pct = getattr(cfg.resources, "cpu_target_pct", 60)
        # 10% to 100% in 10% increments dynamically sizing worker pools
        target_workers = max(1, round(cores * (target_pct / 100.0)))

        if cfg.resources.cpu_limit_enabled:
            configured_max = cfg.resources.cpu_workers_max
            if configured_max and configured_max > 0:
                eff = max(1, min(configured_max, target_workers, cores))
            else:
                eff = max(1, min(target_workers, cores))
        else:
            eff = max(1, min(target_workers, cores))

        # Keep configured evolution workers in sync with dynamically sized workers
        cfg.evolution.workers = eff
        return eff

    def set_cpu_target(self, target_pct: int) -> Dict[str, Any]:
        """Update CPU utilization target (10-100 in 10% steps) and dynamically resize worker pool."""
        target_pct = int(target_pct)
        if target_pct < 10 or target_pct > 100:
            raise ValueError(f"CPU target must be between 10% and 100%, got {target_pct}")
        # normalize to nearest 10%
        target_pct = round(target_pct / 10.0) * 10
        target_pct = max(10, min(100, target_pct))

        from ..config import get_config, save_config
        cfg = get_config()
        cfg.resources.cpu_target_pct = target_pct
        eff = self.effective_workers()
        cfg.evolution.workers = eff
        save_config(cfg)

        msg = f"ACTION: CPU target set to {target_pct}%, worker pool dynamically resized to {eff} workers"
        log.info(msg)
        activity.info("RESOURCE", msg)
        return {"cpu_target_pct": target_pct, "effective_workers": eff}

    def set_gpu_enabled(self, enabled: bool) -> Dict[str, Any]:
        """Persisted GPU acceleration toggle (ON/OFF) with hardware probe & CPU fallback."""
        from ..config import get_config, save_config
        cfg = get_config()
        cfg.resources.gpu_enabled = bool(enabled)
        save_config(cfg)

        with self._lock:
            self._gpu_checked = False
            if not enabled:
                self._gpu_available = False
                self._gpu_name = "Disabled in Settings"
                self._gpu_utilization_pct = 0.0
                self._gpu_vram_used_mb = 0.0
                msg = "ACTION: GPU acceleration disabled (CPU-only mode)"
                log.info(msg)
                activity.info("GPU", msg)
            else:
                self._inspect_gpu(force=True)
                msg = f"ACTION: GPU acceleration enabled (status: {self._gpu_name})"
                log.info(msg)
                activity.info("GPU", msg)

        return {
            "gpu_enabled": cfg.resources.gpu_enabled,
            "gpu_available": self._gpu_available,
            "gpu_name": self._gpu_name,
        }

    def update_job_counts(self, running: int, queued: int, active_workers: int) -> None:
        with self._lock:
            self._running_jobs = running
            self._queued_jobs = queued
            self._active_workers = active_workers

    # ---------- Memory limit enforcement (spec §28) ----------
    def memory_budget_bytes(self) -> int:
        """Calculate user configured memory limit in bytes."""
        cfg = get_config()
        total_ram = psutil.virtual_memory().total
        if not cfg.resources.memory_limit_enabled:
            return total_ram

        val = cfg.resources.memory_limit_value
        mode = cfg.resources.memory_limit_mode
        if mode == "pct":
            pct = max(10.0, min(val, 95.0))
            return int(total_ram * (pct / 100.0))
        else:  # "gb"
            gb = max(1.0, val)
            return int(gb * 1024 * 1024 * 1024)

    def check_memory_budget(self, estimated_mb: float = 200.0) -> bool:
        """Check if executing a workload would exceed the configured memory budget.

        Returns False if system should throttle or pause rather than crash.
        """
        cfg = get_config()
        if not cfg.resources.memory_limit_enabled:
            return True

        vmem = psutil.virtual_memory()
        budget = self.memory_budget_bytes()
        projected = vmem.used + int(estimated_mb * 1024 * 1024)

        if projected > budget:
            activity.warning("RESOURCE",
                             f"Memory budget reached ({vmem.used // (1024**2)}MB used, "
                             f"budget {budget // (1024**2)}MB) — queueing batch")
            return False
        return True

    # ---------- GPU detection & fallback (spec §29, §30, §31) ----------
    def _inspect_gpu(self, force: bool = False) -> None:
        """Safely probe for NVIDIA GPU via nvidia-smi without crashing (spec §31)."""
        if self._gpu_checked and not force:
            return
        self._gpu_checked = True

        cfg = get_config()
        if not cfg.resources.gpu_enabled:
            self._gpu_available = False
            self._gpu_name = "Disabled in Settings"
            return

        smi = shutil.which("nvidia-smi")
        if not smi:
            self._gpu_available = False
            self._gpu_name = "Not detected (CPU fallback)"
            log.info("nvidia-smi not found: GPU disabled, using CPU")
            return

        try:
            out = subprocess.run(
                ["nvidia-smi", "--query-gpu=name,memory.total,memory.used,utilization.gpu",
                 "--format=csv,noheader,nounits"],
                capture_output=True, text=True, timeout=2
            )
            if out.returncode == 0 and out.stdout.strip():
                line = out.stdout.strip().split("\n")[0]
                parts = [p.strip() for p in line.split(",")]
                self._gpu_name = parts[0]
                self._gpu_vram_total_mb = float(parts[1]) if len(parts) > 1 else 0.0
                self._gpu_vram_used_mb = float(parts[2]) if len(parts) > 2 else 0.0
                self._gpu_utilization_pct = float(parts[3]) if len(parts) > 3 else 0.0
                self._gpu_available = True
                activity.success("GPU", f"GPU initialized: {self._gpu_name} ({int(self._gpu_vram_total_mb)}MB VRAM)")
            else:
                self._gpu_available = False
                self._gpu_name = "Unavailable (CPU fallback)"
        except Exception as e:
            self._gpu_available = False
            self._gpu_name = "Unavailable (CPU fallback)"
            activity.warning("GPU", f"GPU initialization failed: {e} — falling back to CPU")

    def live_metrics(self) -> Dict[str, Any]:
        """Live resource monitor snapshot (spec §32, V2.7)."""
        cfg = get_config()
        vmem = psutil.virtual_memory()
        cores_phys = psutil.cpu_count(logical=False) or 1
        cores_log = psutil.cpu_count(logical=True) or 2
        eff_workers = self.effective_workers()
        target_pct = getattr(cfg.resources, "cpu_target_pct", 60)

        # Update GPU
        self._inspect_gpu()

        budget_bytes = self.memory_budget_bytes()
        ram_limit_gb = round(budget_bytes / (1024 ** 3), 1)

        return {
            "cpu": {
                "percent": psutil.cpu_percent(interval=None),
                "target_pct": target_pct,
                "physical_cores": cores_phys,
                "logical_processors": cores_log,
                "configured_workers": cfg.evolution.workers,
                "effective_workers": eff_workers,
                "active_workers": self._active_workers,
                "limit_enabled": cfg.resources.cpu_limit_enabled,
            },
            "memory": {
                "used_mb": round(vmem.used / (1024 ** 2), 1),
                "total_mb": round(vmem.total / (1024 ** 2), 1),
                "percent": vmem.percent,
                "limit_gb": ram_limit_gb,
                "limit_enabled": cfg.resources.memory_limit_enabled,
                "mode": cfg.resources.memory_limit_mode,
                "value": cfg.resources.memory_limit_value,
            },
            "gpu": {
                "enabled": cfg.resources.gpu_enabled,
                "available": self._gpu_available,
                "name": self._gpu_name,
                "utilization_pct": self._gpu_utilization_pct if (cfg.resources.gpu_enabled and self._gpu_available) else 0.0,
                "vram_used_mb": round(self._gpu_vram_used_mb, 1) if (cfg.resources.gpu_enabled and self._gpu_available) else 0.0,
                "vram_total_mb": round(self._gpu_vram_total_mb, 1) if (cfg.resources.gpu_enabled and self._gpu_available) else 0.0,
                "workload_limit_pct": cfg.resources.gpu_workload_limit_pct,
            },
            "workers": {
                "configured": cfg.evolution.workers,
                "effective": eff_workers,
                "active": self._active_workers,
                "target_pct": target_pct,
            },
            "jobs": {
                "running": self._running_jobs,
                "queued": self._queued_jobs,
            },
        }


_res_mgr: Optional[ResourceManager] = None


def get_resource_manager() -> ResourceManager:
    global _res_mgr
    if _res_mgr is None:
        _res_mgr = ResourceManager()
    return _res_mgr
