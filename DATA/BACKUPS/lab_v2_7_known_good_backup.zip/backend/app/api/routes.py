"""REST API for the dashboard."""
from __future__ import annotations

import json
import logging
import threading
import time

log = logging.getLogger("api.routes")

from ..jsonutil import jd
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Body, HTTPException, Query

from ..config import get_config, update_config
from ..db.database import get_db
from ..logging_setup import get_logs
from ..mt5 import bridge_status, get_bridge
from ..mt5.factory import reset_bridge
from ..orchestrator.lab import get_lab
from ..paper import calibration as calib
from ..paper.engine import get_paper_engine
from ..risk.controls import get_risk_manager
from ..genome.schema import describe
from .. import paths as P
from .ws import bus

router = APIRouter(prefix="/api")

COMPONENT_STATES = {
    "dashboard": "operational",
    "database": "operational",
    "genome_dsl": "operational",
    "feature_engine": "operational",
    "backtester": "operational",
    "fitness": "operational",
    "evolution_engine": "operational",
    "validation_engine": "operational",
    "specialization": "operational",
    "paper_trading": "operational",
    "ai_researcher_rules": "operational",
    "ai_researcher_llm": "optional (disabled by default)",
    "risk_controls": "operational",
    "mt5_bridge_real": "available only on Windows with MT5 terminal; otherwise SIMULATOR",
    "mt5_live_execution": "PENDING explicit user activation (never automatic)",
    "gpu_acceleration": "not used (CPU-only by design; optional later)",
    "learned_regime_classifier": "PENDING (rule-based regime features operational)",
    "island_populations_map_elites": "PENDING (phase 5)",
}


# ---------------- status ----------------
@router.get("/status")
def status() -> Dict:
    db = get_db()
    lab = get_lab()
    bs = bridge_status()
    counts = db.count_by_status()
    from ..resources.manager import get_resource_manager
    from ..mt5.monitor import get_connection_monitor
    from ..activity import activity
    from ..orchestrator.stages import get_stage_manager
    rm = get_resource_manager()
    mon = get_connection_monitor()
    sm = get_stage_manager()
    return {
        "lab": lab.status(),
        "bridge": bs,
        "paper": get_paper_engine().status()["running"],
        "status_counts": counts,
        "components": COMPONENT_STATES,
        "resources": rm.live_metrics(),
        "connection": mon.status_details(),
        "current_task": activity.get_current_task(),
        "stage_state": sm.get_unified_task_state(),
        "config_summary": {
            "symbol": get_config().data.symbol,
            "timeframes": get_config().data.timeframes,
            "population_size": get_config().evolution.population_size,
            "max_indicators": get_config().evolution.max_indicators,
            "data_is_simulated": bs["is_simulated"],
        },
        "server_time": time.time(),
    }


# ---------------- lab controls ----------------
@router.post("/lab/start")
def lab_start(payload: Dict[str, Any] = Body(default_factory=dict)) -> Dict:
    mode = payload.get("mode", "continuous")
    target = payload.get("target")
    if target is not None:
        try:
            target = int(target)
        except (ValueError, TypeError):
            target = None
    return get_lab().start(mode, target=target)


@router.post("/lab/pause")
def lab_pause() -> Dict:
    return get_lab().pause()


@router.post("/lab/resume")
def lab_resume() -> Dict:
    return get_lab().resume()


@router.post("/lab/stop")
def lab_stop() -> Dict:
    return get_lab().stop()


@router.post("/lab/reset")
def lab_reset() -> Dict:
    return get_lab().reset_generation()


@router.post("/lab/clear-failed")
def lab_clear_failed() -> Dict:
    return get_lab().clear_failed()


@router.get("/lab/status")
def lab_status() -> Dict:
    return get_lab().status()


@router.post("/lab/recheck")
@router.get("/lab/recheck")
def lab_recheck() -> Dict:
    return get_lab().recheck()


@router.post("/lab/target")
def lab_set_target(payload: Dict[str, Any] = Body(...)) -> Dict:
    raw_target = payload.get("target")
    if raw_target is None:
        raise HTTPException(status_code=400, detail="Missing required 'target' parameter")
    try:
        target = int(raw_target)
        if target <= 0:
            raise ValueError()
    except (ValueError, TypeError):
        raise HTTPException(status_code=400, detail="Target must be a positive integer")
    get_lab().evo.set_total_node_target(target)
    return get_lab().recheck()


@router.get("/lab/target")
def lab_get_target() -> Dict:
    lab = get_lab()
    target = lab.evo.get_total_node_target()
    total_nodes = lab.evo.total_nodes()
    return {
        "target": target,
        "total_nodes": total_nodes,
        "remaining": max(0, target - total_nodes),
        "target_reached": total_nodes >= target,
    }


# ---------------- population / strategies ----------------
@router.get("/population")
def population(limit: int = 200, status: Optional[str] = None,
               sort: str = "fitness", timeframe: Optional[str] = None,
               generation: Optional[int] = None) -> Dict:
    db = get_db()
    where, args = [], []
    if status:
        where.append("status=?"); args.append(status)
    if timeframe:
        where.append("timeframe=?"); args.append(timeframe)
    if generation is not None:
        where.append("generation=?"); args.append(generation)
    wsql = ("WHERE " + " AND ".join(where)) if where else ""
    sort_col = {"fitness": "COALESCE(fitness,-1) DESC", "id": "id DESC",
                "generation": "generation DESC"}[sort]
    rows = db.q(f"""SELECT s.id,s.parent_id,s.generation,s.symbol,s.timeframe,s.direction,
                    s.status,s.fitness,s.species_key,s.complexity,s.mutation_type,
                    s.creation_reason,s.created_at,
                    (SELECT b.metrics FROM backtests b WHERE b.strategy_id=s.id
                       AND b.stage IN ('detail','screen') ORDER BY
                       CASE b.stage WHEN 'detail' THEN 0 ELSE 1 END, b.id DESC LIMIT 1) AS m
                    FROM strategies s {wsql} ORDER BY {sort_col} LIMIT ?""",
                tuple(args) + (limit,))
    out = []
    for r in rows:
        m = json.loads(r.pop("m")) if r.get("m") else {}
        r["pf"] = m.get("profit_factor")
        r["return_pct"] = m.get("total_return_pct")
        r["dd"] = m.get("max_drawdown_pct")
        r["trades"] = m.get("trades")
        r["sharpe"] = m.get("sharpe")
        out.append(r)
    return {"count": len(out), "strategies": out,
            "status_counts": db.count_by_status()}


@router.get("/scatter")
def scatter(x: str = "total_return_pct", y: str = "max_drawdown_pct",
            color: str = "status", limit: int = 800,
            status: Optional[str] = None) -> Dict:
    db = get_db()
    rows = db.q("""SELECT s.id,s.status,s.generation,s.species_key,s.timeframe,
                   s.fitness,s.complexity,
                   (SELECT b.metrics FROM backtests b WHERE b.strategy_id=s.id
                      AND b.stage IN ('detail','screen') ORDER BY
                      CASE b.stage WHEN 'detail' THEN 0 ELSE 1 END, b.id DESC LIMIT 1) AS m
                   FROM strategies s WHERE s.fitness IS NOT NULL
                   ORDER BY s.fitness DESC LIMIT ?""", (limit,))
    metric_keys = {"total_return_pct", "max_drawdown_pct", "profit_factor", "sharpe",
                   "sortino", "trades", "consistency", "win_rate"}
    points = []
    for r in rows:
        m = json.loads(r["m"]) if r.get("m") else {}
        if status and r["status"] != status:
            continue
        def val(k):
            if k == "fitness":
                return r["fitness"]
            if k == "complexity":
                return r["complexity"]
            if k == "generation":
                return r["generation"]
            return m.get(k)
        vx, vy = val(x) if x in metric_keys | {"fitness", "complexity", "generation"} else None, \
                 val(y) if y in metric_keys | {"fitness", "complexity", "generation"} else None
        if vx is None or vy is None:
            continue
        points.append({"id": r["id"], "x": vx, "y": vy,
                       "color": r.get(color) if color in ("status", "timeframe", "generation")
                                else (r["species_key"] if color == "species" else r["status"])})
    return {"x": x, "y": y, "color": color, "points": points}


@router.get("/tree")
def tree(max_nodes: int = 350, status: Optional[str] = None,
         generation_min: Optional[int] = None, generation_max: Optional[int] = None,
         symbol: Optional[str] = None, timeframe: Optional[str] = None,
         alive_only: bool = False, dead_only: bool = False, search: Optional[str] = None,
         focus_id: Optional[int] = None) -> Dict:
    """Ancestry graph, intelligently limited (full history stays in the DB)."""
    db = get_db()
    where, args = [], []
    if status:
        where.append("status=?"); args.append(status)
    if generation_min is not None:
        where.append("generation>=?"); args.append(generation_min)
    if generation_max is not None:
        where.append("generation<=?"); args.append(generation_max)
    if symbol:
        where.append("symbol=?"); args.append(symbol)
    if timeframe:
        where.append("timeframe=?"); args.append(timeframe)
    if alive_only:
        where.append("status NOT IN ('FAILED','KILLED','RETIRED')")
    if dead_only:
        where.append("status IN ('FAILED','KILLED')")
    wsql = ("WHERE " + " AND ".join(where)) if where else ""

    if focus_id is not None:
        # ancestors + descendants of one node
        ids: set[int] = {focus_id}
        cur = db.get_strategy(focus_id)
        while cur and cur.get("parent_id"):
            ids.add(cur["parent_id"])
            cur = db.get_strategy(cur["parent_id"])
        frontier = [focus_id]
        while frontier and len(ids) < max_nodes:
            qm = ",".join("?" * len(frontier))
            kids = db.q(f"SELECT id FROM strategies WHERE parent_id IN ({qm})", tuple(frontier))
            frontier = [k["id"] for k in kids if k["id"] not in ids]
            ids.update(frontier)
        rows = db.q(f"""SELECT * FROM strategies WHERE id IN ({",".join("?" * len(ids))})""",
                    tuple(ids))
    else:
        rows = db.q(f"""SELECT s.*, (SELECT b.metrics FROM backtests b
                        WHERE b.strategy_id=s.id AND b.stage IN ('detail','screen')
                        ORDER BY CASE b.stage WHEN 'detail' THEN 0 ELSE 1 END, b.id DESC
                        LIMIT 1) AS m
                        FROM strategies s {wsql}
                        ORDER BY COALESCE(s.fitness,-1) DESC, s.id DESC LIMIT ?""",
                    tuple(args) + (max_nodes,))
        # include missing parents so lineages connect
        ids = {r["id"] for r in rows}
        missing = {r["parent_id"] for r in rows if r.get("parent_id") and r["parent_id"] not in ids}
        depth = 0
        while missing and depth < 6 and len(ids) + len(missing) < max_nodes * 1.4:
            extra = db.q(f"""SELECT * FROM strategies WHERE id IN
                             ({",".join("?" * len(missing))})""", tuple(missing))
            rows.extend(extra)
            ids |= {e["id"] for e in extra}
            missing = {e["parent_id"] for e in extra
                       if e.get("parent_id") and e["parent_id"] not in ids}
            depth += 1

    if search:
        rows = [r for r in rows if search in str(r["id"]) or
                (r.get("species_key") and search.lower() in r["species_key"].lower()) or
                (r.get("creation_reason") and search.lower() in r["creation_reason"].lower())]

    nodes = []
    for r in rows:
        m = json.loads(r["m"]) if r.get("m") else {}
        nodes.append({
            "id": r["id"], "parent_id": r.get("parent_id"),
            "generation": r["generation"], "status": r["status"],
            "fitness": r.get("fitness"), "symbol": r["symbol"],
            "timeframe": r["timeframe"], "species": r.get("species_key"),
            "pf": m.get("profit_factor"), "return_pct": m.get("total_return_pct"),
            "dd": m.get("max_drawdown_pct"), "trades": m.get("trades"),
            "mutation_type": r.get("mutation_type"),
            "creation_reason": r.get("creation_reason"),
            "failure_reason": r.get("failure_reason"),
            "survival_reason": r.get("survival_reason"),
        })
    node_map = {n["id"]: n for n in nodes}
    edges = []
    for n in nodes:
        pid = n.get("parent_id")
        if pid in node_map:
            p = node_map[pid]
            is_dead = n["status"] in ("FAILED", "KILLED", "RETIRED")
            is_alive = n["status"] in ("QUALIFIED", "PAPER", "SURVIVED", "BORN", "VALIDATING", "BACKTESTING")
            edges.append({
                "source": pid,
                "target": n["id"],
                "target_status": n["status"],
                "source_status": p["status"],
                "is_dead": is_dead,
                "is_alive": is_alive,
                "branch_state": "dead" if is_dead else "active",
            })
    return {"nodes": nodes, "edges": edges, "truncated": len(rows) >= max_nodes,
            "total_strategies": db.one("SELECT COUNT(*) c FROM strategies")["c"]}


@router.get("/strategies/{sid}")
def strategy_detail(sid: int) -> Dict:
    db = get_db()
    row = db.get_strategy(sid)
    if not row:
        raise HTTPException(404, "strategy not found")
    genome = row["genome"]
    bts = db.q("SELECT * FROM backtests WHERE strategy_id=? ORDER BY id DESC LIMIT 12", (sid,))
    for b in bts:
        b["metrics"] = json.loads(b["metrics"])
        b["params"] = json.loads(b["params"]) if b.get("params") else None
        b["window"] = json.loads(b["window"]) if b.get("window") else None
    val = db.one("SELECT * FROM validations WHERE strategy_id=?", (sid,))
    if val:
        for k in ("oos", "walkforward", "perturbation", "spread_stress",
                  "montecarlo", "regime_holdout", "notes"):
            val[k] = json.loads(val[k]) if val.get(k) else None
    mats = db.one("SELECT * FROM matrices WHERE strategy_id=?", (sid,))
    if mats:
        for k in ("timeframe", "session", "day", "regime", "direction"):
            mats[k] = json.loads(mats[k]) if mats.get(k) else None
    # ancestry chain (research history: WHY this strategy exists)
    lineage = []
    cur = row
    while cur:
        lineage.append({"id": cur["id"], "generation": cur["generation"],
                        "status": cur["status"], "mutation_type": cur.get("mutation_type"),
                        "creation_reason": cur.get("creation_reason"),
                        "fitness": cur.get("fitness"), "origin": cur.get("origin")})
        cur = db.get_strategy(cur["parent_id"]) if cur.get("parent_id") else None
    children = db.q("""SELECT id,status,fitness,mutation_type,creation_reason
                       FROM strategies WHERE parent_id=? ORDER BY id LIMIT 50""", (sid,))
    hyps = db.q("SELECT * FROM hypotheses WHERE strategy_id=? ORDER BY id DESC LIMIT 20", (sid,))
    for h in hyps:
        h["proposal"] = json.loads(h["proposal"])
    paper = db.q("""SELECT COUNT(*) n, COALESCE(SUM(pnl),0) pnl,
                    AVG(CASE WHEN pnl>0 THEN 1.0 ELSE 0.0 END) wr
                    FROM paper_trades WHERE strategy_id=? AND status='CLOSED'""", (sid,))[0]
    return {"strategy": {**row, "genome": genome, "description": describe(genome)},
            "backtests": bts, "validation": val, "matrices": mats,
            "lineage": lineage, "children": children, "hypotheses": hyps,
            "paper_summary": paper}


@router.get("/hypotheses")
def hypotheses(limit: int = 100) -> Dict:
    rows = get_db().q("SELECT * FROM hypotheses ORDER BY id DESC LIMIT ?", (limit,))
    for r in rows:
        r["proposal"] = json.loads(r["proposal"])
    return {"hypotheses": rows}


@router.get("/research/memory")
def research_memory(limit: int = 100, outcome: Optional[str] = None) -> Dict:
    db = get_db()
    if not db.one("SELECT name FROM sqlite_master WHERE type='table' AND name='research_memory'"):
        return {"memory": []}
    if outcome:
        rows = db.q("SELECT * FROM research_memory WHERE outcome=? ORDER BY id DESC LIMIT ?", (outcome, limit))
    else:
        rows = db.q("SELECT * FROM research_memory ORDER BY id DESC LIMIT ?", (limit,))
    return {"memory": rows}


def _filter_persisted_strategies(
    min_trades: Optional[int] = None,
    min_trade_duration_seconds: Optional[int] = None,
    min_trade_duration_minutes: Optional[float] = None,
    max_trade_duration_seconds: Optional[int] = None,
    max_trade_duration_minutes: Optional[float] = None,
    min_return_pct: Optional[float] = None,
    max_drawdown_pct: Optional[float] = None,
    min_win_rate: Optional[float] = None,
    min_profit_factor: Optional[float] = None,
    min_sharpe: Optional[float] = None,
    min_sortino: Optional[float] = None,
    min_net_profit: Optional[float] = None,
    max_loss: Optional[float] = None,
    min_avg_trade: Optional[float] = None,
    min_expectancy: Optional[float] = None,
    max_consecutive_losses: Optional[int] = None,
    stage: Optional[str] = None,
    symbol: Optional[str] = None,
    timeframe: Optional[str] = None,
    direction: Optional[str] = None,
    status: Optional[str] = None,
    status_category: Optional[str] = None,
    generation: Optional[int] = None,
    parent_id: Optional[int] = None,
    node_id: Optional[int] = None,
    search: Optional[str] = None,
    limit: int = 100,
    offset: int = 0,
) -> Dict:
    db = get_db()
    if min_trade_duration_minutes is not None and min_trade_duration_seconds is None:
        min_trade_duration_seconds = int(min_trade_duration_minutes * 60)
    if max_trade_duration_minutes is not None and max_trade_duration_seconds is None:
        max_trade_duration_seconds = int(max_trade_duration_minutes * 60)

    shortlist_set = set(db.get_shortlist())

    # Zero-recomputation query of persisted strategies and their backtest metrics
    query = """
        SELECT s.id, s.symbol, s.timeframe, s.direction, s.status, s.fitness, s.parent_id, s.generation,
               s.mutation_type, s.creation_reason, s.created_at,
               b.stage as bt_stage, b.metrics, b.verdict, b.fitness as bt_fitness, b.created_at as bt_created_at
        FROM strategies s
        LEFT JOIN backtests b ON b.strategy_id = s.id AND b.id = (
            SELECT MAX(id) FROM backtests WHERE strategy_id = s.id
        )
        ORDER BY s.id DESC
    """
    rows = db.q(query)
    total_evaluated = 0
    matched = []

    search_clean = (search or "").strip().lower()

    for r in rows:
        m = {}
        if r["metrics"]:
            try:
                m = json.loads(r["metrics"]) if isinstance(r["metrics"], str) else r["metrics"]
            except Exception:
                m = {}
        if m:
            total_evaluated += 1

        # Search matching (exact node id or text filter)
        if search_clean:
            id_match = str(r["id"]) == search_clean
            sym_match = search_clean in (r["symbol"] or "").lower()
            tf_match = search_clean in (r["timeframe"] or "").lower()
            stat_match = search_clean in (r["status"] or "").lower()
            mut_match = search_clean in (r["mutation_type"] or "").lower()
            gen_match = f"gen {r['generation']}" in search_clean or f"gen{r['generation']}" in search_clean or str(r['generation']) == search_clean
            parent_match = search_clean in f"node_{r['parent_id']}" or str(r['parent_id']) == search_clean
            if not (id_match or sym_match or tf_match or stat_match or mut_match or gen_match or parent_match):
                continue

        if node_id is not None and r["id"] != node_id:
            continue
        if parent_id is not None and r["parent_id"] != parent_id:
            continue
        if generation is not None and r["generation"] != generation:
            continue
        if status and r["status"] != status:
            continue
        if status_category:
            cat = status_category.upper()
            if cat == "QUALIFIED" and r["status"] not in ("QUALIFIED", "PAPER"):
                continue
            elif cat == "ALIVE" and r["status"] not in ("BORN", "BACKTESTING", "SURVIVED", "VALIDATING", "QUALIFIED", "PAPER"):
                continue
            elif cat == "DEAD" and r["status"] not in ("FAILED", "KILLED", "RETIRED"):
                continue
        if symbol and r["symbol"] != symbol:
            continue
        if timeframe and r["timeframe"] != timeframe:
            continue
        if direction and direction.lower() != "both" and (r["direction"] or "both").lower() != direction.lower():
            continue
        if stage and (r["bt_stage"] or "").lower() != stage.lower():
            continue

        # Metric filters
        if min_trades is not None and m.get("trades", 0) < min_trades:
            continue
        if min_trade_duration_seconds is not None:
            # Check avg or min trade duration
            avg_dur = m.get("avg_trade_duration_seconds", 0)
            if avg_dur < min_trade_duration_seconds:
                continue
        if max_trade_duration_seconds is not None:
            avg_dur = m.get("avg_trade_duration_seconds", 0)
            if avg_dur > max_trade_duration_seconds:
                continue
        if min_return_pct is not None and m.get("total_return_pct", -999.0) < min_return_pct:
            continue
        if max_drawdown_pct is not None and m.get("max_drawdown_pct", 999.0) > max_drawdown_pct:
            continue
        if min_win_rate is not None and m.get("win_rate", 0.0) < min_win_rate:
            continue
        if min_profit_factor is not None and m.get("profit_factor", 0.0) < min_profit_factor:
            continue
        if min_sharpe is not None and m.get("sharpe", -99.0) < min_sharpe:
            continue
        if min_sortino is not None and m.get("sortino", -99.0) < min_sortino:
            continue
        if min_net_profit is not None and m.get("net_profit", -999999.0) < min_net_profit:
            continue
        if min_avg_trade is not None and m.get("avg_trade", -99999.0) < min_avg_trade:
            continue
        if min_expectancy is not None and m.get("expectancy", -99999.0) < min_expectancy:
            continue

        trades_sample = m.get("trades_sample", [])
        # Consecutive loss & largest loss calculation if trades_sample present
        cons_losses = 0
        max_cons_losses = 0
        cons_wins = 0
        max_cons_wins = 0
        largest_win = 0.0
        largest_loss = 0.0
        min_dur_s = m.get("min_trade_duration_seconds", 0)
        max_dur_s = m.get("max_trade_duration_seconds", 0)

        if trades_sample:
            durations = []
            cur_cl = 0
            cur_cw = 0
            for t in trades_sample:
                pnl = t.get("pnl", 0.0)
                if pnl > largest_win:
                    largest_win = pnl
                if pnl < largest_loss:
                    largest_loss = pnl
                if pnl < 0:
                    cur_cl += 1
                    cur_cw = 0
                    if cur_cl > max_cons_losses:
                        max_cons_losses = cur_cl
                elif pnl > 0:
                    cur_cw += 1
                    cur_cl = 0
                    if cur_cw > max_cons_wins:
                        max_cons_wins = cur_cw
                e_ts = t.get("entry_ts", 0)
                x_ts = t.get("exit_ts", 0)
                if e_ts and x_ts and x_ts > e_ts:
                    durations.append(x_ts - e_ts)
            if durations:
                min_dur_s = min(durations)
                max_dur_s = max(durations)

        if max_consecutive_losses is not None and max_cons_losses > max_consecutive_losses:
            continue
        if max_loss is not None and abs(largest_loss) > abs(max_loss):
            continue

        matched.append({
            "id": r["id"],
            "symbol": r["symbol"],
            "timeframe": r["timeframe"],
            "direction": r.get("direction", "both"),
            "status": r["status"],
            "fitness": r["fitness"],
            "parent_id": r["parent_id"],
            "generation": r["generation"],
            "mutation_type": r["mutation_type"],
            "creation_reason": r.get("creation_reason", ""),
            "stage": r["bt_stage"] or "NONE",
            "verdict": r["verdict"] or "NONE",
            "trades": m.get("trades", 0),
            "total_return_pct": m.get("total_return_pct", 0.0),
            "net_profit": m.get("net_profit", 0.0),
            "max_drawdown_pct": m.get("max_drawdown_pct", 0.0),
            "win_rate": m.get("win_rate", 0.0),
            "profit_factor": m.get("profit_factor", 0.0),
            "sharpe": m.get("sharpe", 0.0),
            "sortino": m.get("sortino", 0.0),
            "avg_trade": m.get("avg_trade", 0.0),
            "expectancy": m.get("expectancy", 0.0),
            "avg_trade_duration_seconds": m.get("avg_trade_duration_seconds", 0),
            "min_trade_duration_seconds": min_dur_s,
            "max_trade_duration_seconds": max_dur_s,
            "largest_win": largest_win,
            "largest_loss": largest_loss,
            "consecutive_wins": max_cons_wins,
            "consecutive_losses": max_cons_losses,
            "created_at": r["created_at"],
            "shortlisted": r["id"] in shortlist_set,
        })

    paginated = matched[offset:offset + limit]
    return {
        "total_evaluated": total_evaluated,
        "total_matching": len(matched),
        "recomputed": False,
        "limit": limit,
        "offset": offset,
        "filters_applied": {
            "min_trades": min_trades,
            "min_trade_duration_seconds": min_trade_duration_seconds,
            "max_trade_duration_seconds": max_trade_duration_seconds,
            "min_return_pct": min_return_pct,
            "max_drawdown_pct": max_drawdown_pct,
            "min_win_rate": min_win_rate,
            "min_profit_factor": min_profit_factor,
            "min_sharpe": min_sharpe,
            "min_sortino": min_sortino,
            "min_net_profit": min_net_profit,
            "max_loss": max_loss,
            "min_avg_trade": min_avg_trade,
            "min_expectancy": min_expectancy,
            "max_consecutive_losses": max_consecutive_losses,
            "stage": stage,
            "symbol": symbol,
            "timeframe": timeframe,
            "direction": direction,
            "status": status,
            "status_category": status_category,
            "generation": generation,
            "parent_id": parent_id,
            "node_id": node_id,
            "search": search,
        },
        "strategies": paginated,
    }


@router.get("/research/shortlist/saved")
def get_saved_shortlist() -> Dict:
    db = get_db()
    sids = db.get_shortlist()
    return {"shortlist": sids}


@router.post("/research/shortlist/toggle")
def toggle_shortlist_item(payload: Dict = Body(...)) -> Dict:
    db = get_db()
    sid = int(payload.get("strategy_id", 0))
    if not sid:
        raise HTTPException(400, "strategy_id is required")
    sids = db.get_shortlist()
    if sid in sids:
        db.remove_from_shortlist(sid)
        shortlisted = False
    else:
        db.add_to_shortlist(sid, payload.get("notes", ""))
        shortlisted = True
    return {"ok": True, "strategy_id": sid, "shortlisted": shortlisted, "shortlist": db.get_shortlist()}


@router.post("/research/shortlist/clear")
def clear_saved_shortlist() -> Dict:
    db = get_db()
    db.clear_shortlist()
    return {"ok": True, "shortlist": []}


@router.get("/strategies/{sid}/trades")
def get_strategy_trades(sid: int) -> Dict:
    db = get_db()
    strat = db.get_strategy(sid)
    if not strat:
        raise HTTPException(404, f"Strategy #{sid} not found")
    bt = db.one("SELECT metrics FROM backtests WHERE strategy_id=? ORDER BY id DESC LIMIT 1", (sid,))
    trades = []
    if bt and bt.get("metrics"):
        try:
            m = json.loads(bt["metrics"]) if isinstance(bt["metrics"], str) else bt["metrics"]
            raw_trades = m.get("trades_sample", [])
            for idx, t in enumerate(raw_trades, 1):
                e_ts = t.get("entry_ts", 0)
                x_ts = t.get("exit_ts", 0)
                dur_s = max(0, x_ts - e_ts) if (e_ts and x_ts) else (t.get("hold_bars", 1) * 3600)
                trades.append({
                    "trade_num": idx,
                    "side": t.get("side", "buy").upper(),
                    "entry_ts": e_ts,
                    "exit_ts": x_ts,
                    "entry_price": t.get("entry_price", 0.0),
                    "exit_price": t.get("exit_price", 0.0),
                    "duration_seconds": dur_s,
                    "duration_minutes": round(dur_s / 60.0, 1),
                    "pnl": t.get("pnl", 0.0),
                    "pnl_pct": round(t.get("pnl", 0.0) / 10000.0 * 100, 3),
                    "exit_reason": t.get("exit_reason", "SIGNAL"),
                    "session": t.get("session", "–"),
                })
        except Exception:
            pass
    return {"strategy_id": sid, "total_trades": len(trades), "trades": trades}


@router.post("/strategies/{sid}/backtest")
def rerun_strategy_backtest(sid: int) -> Dict:
    db = get_db()
    strat = db.get_strategy(sid)
    if not strat:
        raise HTTPException(404, f"Strategy #{sid} not found")
    genome = strat["genome"]
    from ..data.engine import get_data_engine
    de = get_data_engine()
    ds_info = de.latest_dataset(genome["symbol"], genome["timeframe"])
    if not ds_info:
        raise HTTPException(400, f"No dataset found for {genome['symbol']} {genome['timeframe']}")
    split = de.train_test_split(ds_info["id"])
    w = (0, split["cut"])
    from ..orchestrator.lab import get_lab, _bt_payload
    from ..fitness.evaluator import fitness, death_check
    payload = _bt_payload(genome, ds_info["id"], "detail", window=w)
    lab = get_lab()
    res = lab._run_batch([payload])[0]
    if res["ok"]:
        m = res["metrics"]
        m["trades_sample"] = res["trades"][-300:]
        f, components = fitness(m, genome)
        died, reasons = death_check(m, genome, stage="detail")
        verdict = "KILLED" if died else "SURVIVED"
        db.x("""INSERT INTO backtests
                     (strategy_id,stage,dataset_id,window,params,metrics,fitness,
                      verdict,created_at,fingerprint,dataset_version,engine_versions)
                     VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                  (sid, "detail", ds_info["id"], json.dumps(m.get("window")),
                   json.dumps({"components": components}), json.dumps(m), f,
                   verdict, time.time(),
                   "", ds_info.get("dataset_version", 1), json.dumps(manifest())))
        db.update_strategy(sid, fitness=f, status=verdict)
        return {"ok": True, "metrics": m, "fitness": f, "verdict": verdict}
    else:
        raise HTTPException(500, f"Backtest execution failed: {res.get('error')}")


@router.post("/strategies/{sid}/validate")
def run_strategy_validation(sid: int) -> Dict:
    db = get_db()
    strat = db.get_strategy(sid)
    if not strat:
        raise HTTPException(404, f"Strategy #{sid} not found")
    bt = db.one("SELECT * FROM backtests WHERE strategy_id=? ORDER BY id DESC LIMIT 1", (sid,))
    if not bt:
        raise HTTPException(400, "Strategy has no backtest results to validate")
    base_metrics = json.loads(bt["metrics"]) if isinstance(bt["metrics"], str) else bt["metrics"]
    base_fitness = bt["fitness"] or 0.0
    from ..validation.battery import full_validation
    v = full_validation(strat, base_metrics, base_fitness, base_metrics.get("trades_sample", []))
    passed = v.get("passed", False)
    db.x("""INSERT OR REPLACE INTO validations
                 (strategy_id,oos,walkforward,perturbation,spread_stress,slippage_stress,
                  montecarlo,regime_holdout,robustness_score,passed,notes,created_at,fingerprint)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
              (sid, json.dumps(v.get("oos")), json.dumps(v.get("walkforward")),
               json.dumps(v.get("perturbation")), json.dumps(v.get("spread_slippage_stress")), None,
               json.dumps(v.get("montecarlo")), json.dumps(v.get("regime_holdout")),
               v.get("robustness_score"), 1 if passed else 0,
               json.dumps(v.get("death_reasons", [])), time.time(), ""))
    new_status = "QUALIFIED" if passed else "KILLED"
    db.update_strategy(sid, status=new_status)
    return {"ok": True, "passed": passed, "status": new_status, "validation": v}


@router.get("/research/shortlist")
def get_research_shortlist(
    min_trades: Optional[int] = None,
    min_trade_duration_seconds: Optional[int] = None,
    min_trade_duration_minutes: Optional[float] = None,
    min_return_pct: Optional[float] = None,
    max_drawdown_pct: Optional[float] = None,
    min_win_rate: Optional[float] = None,
    min_profit_factor: Optional[float] = None,
    stage: Optional[str] = None,
    symbol: Optional[str] = None,
    status: Optional[str] = None,
    limit: int = 100,
    offset: int = 0,
) -> Dict:
    """Zero-recomputation shortlist of evaluated strategies filtered against post-evaluation criteria."""
    return _filter_persisted_strategies(
        min_trades=min_trades,
        min_trade_duration_seconds=min_trade_duration_seconds,
        min_trade_duration_minutes=min_trade_duration_minutes,
        min_return_pct=min_return_pct,
        max_drawdown_pct=max_drawdown_pct,
        min_win_rate=min_win_rate,
        min_profit_factor=min_profit_factor,
        stage=stage,
        symbol=symbol,
        status=status,
        limit=limit,
        offset=offset,
    )


@router.post("/research/filter")
def post_research_filter(payload: Dict = Body(...)) -> Dict:
    """Filter persisted strategy backtest results without recomputing historical backtests."""
    return _filter_persisted_strategies(
        min_trades=payload.get("min_trades"),
        min_trade_duration_seconds=payload.get("min_trade_duration_seconds"),
        min_trade_duration_minutes=payload.get("min_trade_duration_minutes"),
        max_trade_duration_seconds=payload.get("max_trade_duration_seconds"),
        max_trade_duration_minutes=payload.get("max_trade_duration_minutes"),
        min_return_pct=payload.get("min_return_pct"),
        max_drawdown_pct=payload.get("max_drawdown_pct"),
        min_win_rate=payload.get("min_win_rate"),
        min_profit_factor=payload.get("min_profit_factor"),
        min_sharpe=payload.get("min_sharpe"),
        min_sortino=payload.get("min_sortino"),
        min_net_profit=payload.get("min_net_profit"),
        max_loss=payload.get("max_loss"),
        min_avg_trade=payload.get("min_avg_trade"),
        min_expectancy=payload.get("min_expectancy"),
        max_consecutive_losses=payload.get("max_consecutive_losses"),
        stage=payload.get("stage"),
        symbol=payload.get("symbol"),
        timeframe=payload.get("timeframe"),
        direction=payload.get("direction"),
        status=payload.get("status"),
        status_category=payload.get("status_category"),
        generation=payload.get("generation"),
        parent_id=payload.get("parent_id"),
        node_id=payload.get("node_id"),
        search=payload.get("search"),
        limit=int(payload.get("limit", 100)),
        offset=int(payload.get("offset", 0)),
    )


@router.post("/hypotheses/{hid}/apply")
def hypothesis_apply(hid: int) -> Dict:
    from ..ai_researcher.analyzer import apply_hypothesis
    child = apply_hypothesis(hid)
    if child is None:
        raise HTTPException(400, "hypothesis could not be applied (invalid/duplicate/rejected)")
    bus.publish("hypothesis_applied", {"hypothesis_id": hid, "child_strategy_id": child})
    return {"ok": True, "child_strategy_id": child}


# ---------------- data ----------------
@router.get("/data/inventory")
def data_inventory() -> Dict:
    """Comprehensive Data Inventory of persisted datasets, features, and manifests (V2.7)."""
    from pathlib import Path
    from ..paths import (
        DATA_ROOT, MT5_RAW_DIR, MT5_NORMALIZED_DIR, FEATURES_DIR, MANIFESTS_DIR,
        DATASETS_MANIFEST, FEATURES_MANIFEST, RESEARCH_MANIFEST, data_relative_path
    )
    from ..data.manifest import get_datasets_manifest, get_features_manifest, sync_manifests_from_disk
    from ..features.engine import get_feature_engine
    from datetime import datetime, timezone

    # Ensure manifests are synced
    sync_manifests_from_disk()
    ds_man = get_datasets_manifest().get("datasets", {})
    ft_man = get_features_manifest().get("features", {})
    db = get_db()

    datasets_list = []
    total_raw_bars = 0
    raw_storage_bytes = 0

    # 1. Inspect datasets from DB and DATA/MT5/raw/
    db_rows = db.q("SELECT * FROM datasets ORDER BY id DESC")
    seen_keys = set()

    for r in db_rows:
        did = r["id"]
        sym = r["symbol"]
        tf = r["timeframe"]
        key = f"{sym}_{tf}"
        seen_keys.add(key)
        bars = int(r.get("bars", 0))
        total_raw_bars += bars

        raw_p = MT5_RAW_DIR / f"{sym}_{tf}.parquet"
        norm_p = MT5_NORMALIZED_DIR / f"{sym}_{tf}.parquet"
        size_bytes = raw_p.stat().st_size if raw_p.exists() else (Path(r["path"]).stat().st_size if r.get("path") and Path(r["path"]).exists() else 0)
        raw_storage_bytes += size_bytes

        cached_feats = get_feature_engine().cached_features(did)
        prof = r.get("master_profile") or ""
        broker_val = prof.split("|")[1] if "|" in prof else "MetaQuotes"

        datasets_list.append({
            "id": did,
            "symbol": sym,
            "timeframe": tf,
            "rows": bars,
            "start_ts": float(r.get("start_ts", 0)),
            "end_ts": float(r.get("end_ts", 0)),
            "start_date": datetime.fromtimestamp(float(r.get("start_ts", 0)), tz=timezone.utc).strftime("%Y-%m-%d %H:%M"),
            "end_date": datetime.fromtimestamp(float(r.get("end_ts", 0)), tz=timezone.utc).strftime("%Y-%m-%d %H:%M"),
            "source": r.get("source", "MT5"),
            "broker": broker_val,
            "raw_file": data_relative_path(raw_p) if raw_p.exists() else data_relative_path(r.get("path", "")),
            "normalized_file": data_relative_path(norm_p) if norm_p.exists() else None,
            "size_mb": round(size_bytes / (1024 * 1024), 2),
            "feature_status": f"Cached ({len(cached_feats)} features)" if cached_feats else "Ready to compute",
            "feature_count": len(cached_feats),
            "is_reusable": True,
            "status": "READY",
        })

    # Add any manifest datasets not in DB
    for k, v in ds_man.items():
        if k not in seen_keys:
            raw_p = DATA_ROOT / v.get("raw_path", "")
            size_bytes = raw_p.stat().st_size if raw_p.exists() else v.get("file_size_bytes", 0)
            raw_storage_bytes += size_bytes
            rows_cnt = v.get("rows", 0)
            total_raw_bars += rows_cnt
            datasets_list.append({
                "id": v.get("dataset_id", k),
                "symbol": v.get("symbol", k.split("_")[0]),
                "timeframe": v.get("timeframe", k.split("_")[1] if "_" in k else "M15"),
                "rows": rows_cnt,
                "start_ts": v.get("first_ts", 0),
                "end_ts": v.get("last_ts", 0),
                "start_date": v.get("start_time", "–"),
                "end_date": v.get("end_time", "–"),
                "source": v.get("source", "MT5"),
                "broker": v.get("broker", "UNKNOWN"),
                "raw_file": v.get("raw_path", ""),
                "normalized_file": v.get("normalized_path", ""),
                "size_mb": round(size_bytes / (1024 * 1024), 2),
                "feature_status": "Persisted on disk",
                "feature_count": 0,
                "is_reusable": True,
                "status": "PERSISTED",
            })

    # 2. Inspect features
    features_list = []
    feat_storage_bytes = 0
    if FEATURES_DIR.exists():
        for fp in sorted(FEATURES_DIR.glob("*.parquet")):
            sz = fp.stat().st_size
            feat_storage_bytes += sz
            m_entry = ft_man.get(fp.stem, {})
            features_list.append({
                "feature_key": fp.stem,
                "relative_path": data_relative_path(fp),
                "size_mb": round(sz / (1024 * 1024), 2),
                "column_count": m_entry.get("column_count") or (len(m_entry.get("columns", [])) if "columns" in m_entry else 21),
                "columns": m_entry.get("columns", []),
                "rows": m_entry.get("rows", 0),
                "last_updated": fp.stat().st_mtime,
                "schema_version": m_entry.get("schema_version", "core_v1"),
            })

    total_storage_mb = round((raw_storage_bytes + feat_storage_bytes) / (1024 * 1024), 2)

    return {
        "data_root": str(DATA_ROOT),
        "summary": {
            "total_datasets": len(datasets_list),
            "total_raw_bars": total_raw_bars,
            "total_features_cached": len(features_list),
            "raw_storage_mb": round(raw_storage_bytes / (1024 * 1024), 2),
            "features_storage_mb": round(feat_storage_bytes / (1024 * 1024), 2),
            "total_storage_mb": total_storage_mb,
        },
        "datasets": datasets_list,
        "features": features_list,
        "manifests": {
            "datasets_manifest": data_relative_path(DATASETS_MANIFEST),
            "features_manifest": data_relative_path(FEATURES_MANIFEST),
            "research_manifest": data_relative_path(RESEARCH_MANIFEST),
        },
    }


@router.get("/data/datasets")
def datasets() -> Dict:
    from ..data.engine import get_data_engine
    from ..features.engine import get_feature_engine
    de = get_data_engine()
    rows = de.list_datasets()
    for r in rows:
        r["cached_features"] = len(get_feature_engine().cached_features(r["id"])) if r["on_disk"] else 0
    return {"datasets": rows, "bridge": bridge_status()["active_bridge"],
            "simulated": bridge_status()["is_simulated"]}


@router.post("/data/ingest")
def ingest(payload: Dict = Body(...)) -> Dict:
    from ..data.engine import get_data_engine
    symbol = payload.get("symbol") or get_config().data.symbol
    tf = payload.get("timeframe") or "M15"
    months = payload.get("months")
    try:
        res = get_data_engine().ingest(symbol, tf, months=months,
                                       force=bool(payload.get("force")))
    except Exception as e:
        raise HTTPException(500, str(e))
    bus.publish("dataset_ingested", res)
    return res


@router.get("/data/bars")
def bars(dataset_id: str, limit: int = 500) -> Dict:
    from ..data.engine import get_data_engine
    try:
        df = get_data_engine().get_frame(dataset_id)
    except KeyError as e:
        raise HTTPException(404, str(e))
    tail = df.tail(limit)
    return {"dataset_id": dataset_id, "total_bars": len(df),
            "bars": tail[["ts", "open", "high", "low", "close", "bid", "ask",
                          "spread", "tick_volume", "session"]].to_dict("records")}


@router.get("/data/features")
def features(dataset_id: str) -> Dict:
    from ..features.engine import get_feature_engine
    return {"dataset_id": dataset_id,
            "cached": get_feature_engine().cached_features(dataset_id),
            "cache_stats": get_feature_engine().cache_stats()}


@router.get("/data/ticks")
def ticks(symbol: Optional[str] = None, n: int = 1) -> Dict:
    sym = symbol or get_config().data.symbol
    bridge = get_bridge()
    out = [bridge.latest_tick(sym) for _ in range(n)]
    return {"symbol": sym, "source": bridge.source,
            "ticks": [t.__dict__ for t in out if t]}


# ---------------- paper ----------------
@router.get("/paper/status")
def paper_status() -> Dict:
    return get_paper_engine().status()


@router.post("/paper/start")
def paper_start() -> Dict:
    return get_paper_engine().start()


@router.post("/paper/stop")
def paper_stop() -> Dict:
    return get_paper_engine().stop()


@router.get("/paper/trades")
def paper_trades(limit: int = 200, strategy_id: Optional[int] = None) -> Dict:
    db = get_db()
    if strategy_id:
        rows = db.q("SELECT * FROM paper_trades WHERE strategy_id=? ORDER BY id DESC LIMIT ?",
                    (strategy_id, limit))
    else:
        rows = db.q("SELECT * FROM paper_trades ORDER BY id DESC LIMIT ?", (limit,))
    summary = db.one("""SELECT COUNT(*) n,
                        SUM(CASE WHEN status='OPEN' THEN 1 ELSE 0 END) open_n,
                        COALESCE(SUM(CASE WHEN status='CLOSED' THEN pnl END),0) pnl,
                        AVG(CASE WHEN status='CLOSED' THEN slippage_points END) slip,
                        AVG(CASE WHEN status='CLOSED' THEN spread_points END) spread,
                        AVG(CASE WHEN status='CLOSED' THEN exec_delay_ms END) delay
                        FROM paper_trades""")
    return {"trades": rows, "summary": summary}


@router.get("/paper/executions")
def paper_executions(limit: int = 200) -> Dict:
    rows = get_db().q("SELECT * FROM executions ORDER BY id DESC LIMIT ?", (limit,))
    return {"executions": rows}


@router.get("/calibration")
def calibration() -> Dict:
    return calib.report()


@router.post("/calibration/recalibrate")
def recalibrate() -> Dict:
    res = calib.recalibrate(apply_to_config=True)
    bus.publish("recalibrated", res["applied"])
    return res


# ---------------- risk ----------------
@router.get("/risk")
def risk() -> Dict:
    return get_risk_manager().snapshot()


@router.post("/risk/kill-switch")
def kill_switch(payload: Dict = Body(...)) -> Dict:
    on = bool(payload.get("on"))
    get_risk_manager().set_kill_switch(on)
    bus.publish("kill_switch", {"on": on})
    return {"ok": True, "kill_switch": on}


@router.post("/risk/real-execution")
def real_execution(payload: Dict = Body(...)) -> Dict:
    """Explicit user activation for real trading. Requires typed confirmation.
    Even then, orders only flow through the risk-gated execution layer."""
    confirm = payload.get("confirm")
    if confirm != "ENABLE REAL TRADING":
        raise HTTPException(400, "confirmation phrase required: 'ENABLE REAL TRADING'")
    bridge = get_bridge()
    if bridge.source != "MT5":
        raise HTTPException(400, "real execution requires a connected REAL MT5 bridge "
                                 "(current feed is SIMULATOR)")
    update_config("risk", {"real_execution_enabled": bool(payload.get("enabled", True))})
    bus.publish("real_execution_toggled", {"enabled": payload.get("enabled", True)})
    return {"ok": True, "real_execution_enabled": bool(payload.get("enabled", True))}


# ---------------- jobs & real progress tracking (V2.7) ----------------
@router.get("/jobs")
def get_jobs(limit: int = 50) -> Dict:
    """List tracked jobs with multi-level progress, real counters, ETA, and stall detection."""
    from ..jobs import get_job_manager
    jm = get_job_manager()
    active = jm.get_active_job()
    return {
        "jobs": jm.list_jobs(limit=limit),
        "active_job": active.to_dict() if active else None,
    }


@router.get("/jobs/{job_id}")
def get_job_detail(job_id: str) -> Dict:
    """Get single job details including stages, tasks, workers, and stall duration."""
    from ..jobs import get_job_manager
    job = get_job_manager().get_job(job_id)
    if not job:
        raise HTTPException(404, f"job {job_id} not found")
    return job.to_dict()


# ---------------- settings ----------------
@router.get("/settings")
def settings() -> Dict:
    from dataclasses import asdict
    cfg = get_config()
    out = {k: asdict(getattr(cfg, k)) for k in
           ("mt5", "data", "evolution", "backtest", "fitness", "risk", "paper", "ai",
            "resources", "research", "appearance")}
    out["database_path"] = cfg.database_path
    out["log_level"] = cfg.log_level
    out["cpu_target_pct"] = getattr(cfg.resources, "cpu_target_pct", 60)
    out["gpu_enabled"] = cfg.resources.gpu_enabled
    return out


@router.post("/settings")
def post_apply_settings(payload: Dict = Body(...)) -> Dict:
    """Apply settings immediately, validate, resize worker pools dynamically, and persist to CONFIG/settings.json."""
    from ..config import get_config, save_config, update_config
    from ..resources.manager import get_resource_manager
    from ..orchestrator.lab import get_lab
    from ..activity import activity

    cfg = get_config()
    rm = get_resource_manager()
    changes = []

    # 1. CPU utilization target control (10%-100% in 10% steps, default 60%)
    if "cpu_target_pct" in payload:
        try:
            val = int(payload["cpu_target_pct"])
            val = max(10, min(100, round(val / 10.0) * 10))
            if getattr(cfg.resources, "cpu_target_pct", 60) != val:
                rm.set_cpu_target(val)
                eff = rm.effective_workers()
                changes.append(f"CPU target utilization set to {val}% (dynamic worker pool: {eff} workers)")
        except Exception as e:
            raise HTTPException(400, f"Invalid cpu_target_pct: {e}")

    # 2. GPU acceleration toggle (ON / OFF)
    if "gpu_enabled" in payload:
        gpu_on = bool(payload["gpu_enabled"])
        if cfg.resources.gpu_enabled != gpu_on:
            rm_rep = rm.set_gpu_enabled(gpu_on)
            state_str = "ENABLED (" + rm_rep["gpu_name"] + ")" if gpu_on else "DISABLED (CPU fallback)"
            changes.append(f"GPU acceleration toggled {state_str}")

    # 3. Total Node Target control
    if "total_node_target" in payload or "target_nodes" in payload:
        val = int(payload.get("total_node_target") or payload.get("target_nodes"))
        val = max(10, min(100_000, val))
        update_config("evolution", {"total_node_target": val})
        changes.append(f"Total node target set to {val}")

    # 4. Minimum Trade Time control
    if "min_trade_duration_seconds" in payload:
        val = int(payload["min_trade_duration_seconds"])
        val = max(0, val)
        update_config("backtest", {"min_trade_duration_seconds": val})
        changes.append(f"Minimum trade duration set to {val}s")
    elif "min_trade_duration_minutes" in payload:
        val = int(round(float(payload["min_trade_duration_minutes"]) * 60))
        val = max(0, val)
        update_config("backtest", {"min_trade_duration_seconds": val})
        changes.append(f"Minimum trade duration set to {val}s")

    # 5. Section updates
    for sec in ("resources", "evolution", "backtest", "fitness", "risk", "paper", "ai", "research", "appearance", "mt5", "data"):
        if sec in payload and isinstance(payload[sec], dict):
            sec_dict = payload[sec]
            if sec == "resources":
                if "cpu_target_pct" in sec_dict:
                    val = int(sec_dict["cpu_target_pct"])
                    val = max(10, min(100, round(val / 10.0) * 10))
                    rm.set_cpu_target(val)
                    changes.append(f"CPU target utilization set to {val}%")
                if "gpu_enabled" in sec_dict:
                    gpu_on = bool(sec_dict["gpu_enabled"])
                    rm.set_gpu_enabled(gpu_on)
                    changes.append(f"GPU acceleration toggled {'ON' if gpu_on else 'OFF'}")
            try:
                update_config(sec, sec_dict)
                changes.append(f"Updated section: {sec}")
            except Exception as e:
                log.warning("failed to update section %s: %s", sec, e)

    save_config(cfg)
    try:
        lab = get_lab()
        if lab:
            lab.resize_pool()
    except Exception:
        pass

    bus.publish("settings_updated", {"applied": True, "changes": changes})
    activity.info("SYSTEM", f"APPLY SETTINGS: {'; '.join(changes) if changes else 'settings saved'}")

    return {
        "success": True,
        "applied": True,
        "changes": changes,
        "settings": settings(),
        "resources": rm.live_metrics(),
    }


@router.put("/settings/{section}")
def put_settings(section: str, values: Dict = Body(...)) -> Dict:
    valid_sections = ("mt5", "data", "evolution", "backtest", "fitness", "risk",
                      "paper", "ai", "resources", "research", "appearance")
    if section not in valid_sections:
        raise HTTPException(400, f"unknown section {section}")
    try:
        cfg = update_config(section, values)
    except Exception as e:
        raise HTTPException(400, str(e))
    bus.publish("settings_updated", {"section": section, "values": values})
    if section == "mt5":
        reset_bridge()
    return {"ok": True, "section": section}


# ---------------- activity & monitoring (spec §20, §32, V2.7) ----------------
@router.get("/activity")
def get_activity_events(
    limit: int = 300,
    category: Optional[str] = None,
    level: Optional[str] = None,
    status: Optional[str] = None,
    sort: str = "desc",
    filter: Optional[str] = None,
) -> List[Dict]:
    """Fetch activity events with V2.7 filter controls and ordering (newest first by default)."""
    from ..activity import activity
    return activity.recent(
        limit=limit,
        category=category,
        level=level,
        status=status,
        sort=sort,
        filter_mode=filter,
    )


@router.get("/logs/diagnostic")
def get_diagnostic_log(limit: int = 300) -> Dict:
    """Format and return complete diagnostic log for COPY LOG button (V2.7)."""
    from ..activity import activity
    text = activity.generate_diagnostic_log(limit=limit)
    return {"diagnostic_text": text, "generated_at": time.time()}


@router.get("/activity/current_task")
def get_current_task() -> Dict:
    from ..activity import activity
    return activity.get_current_task()


@router.get("/resources")
def get_resources() -> Dict:
    from ..resources.manager import get_resource_manager
    return get_resource_manager().live_metrics()


@router.get("/mt5/status")
def get_mt5_monitor_status() -> Dict:
    from ..mt5.monitor import get_connection_monitor
    mon = get_connection_monitor().status_details()
    bs = bridge_status()
    return {**mon, "bridge_status": bs}


@router.get("/mt5/terminals")
def get_discovered_terminals() -> List[Dict]:
    from ..mt5.discovery import discover_terminals
    return discover_terminals()


@router.get("/mt5/config")
def get_mt5_config() -> Dict:
    from ..mt5.config import load_mt5_config
    return load_mt5_config()


@router.post("/mt5/connect")
def post_mt5_connect(body: Dict = Body(default={})) -> Dict:
    from ..mt5.factory import connect_mt5_terminal
    from ..mt5.discovery import validate_terminal_path
    path = body.get("terminal_path", "").strip() if body else ""
    if path:
        valid, reason = validate_terminal_path(path)
        if not valid:
            raise HTTPException(400, f"Invalid terminal path: {reason}")
    status = connect_mt5_terminal(path or None)
    return {"ok": True, "status": status}


@router.post("/mt5/disconnect")
def post_mt5_disconnect() -> Dict:
    from ..mt5.factory import disconnect_mt5_terminal
    status = disconnect_mt5_terminal()
    return {"ok": True, "status": status}


# ---------------- backup & versions (spec §40, §41) ----------------
@router.get("/system/versions")
def get_versions() -> Dict:
    from ..versions import manifest
    return manifest()


@router.post("/backup")
def run_backup() -> Dict:
    from ..backup.backup import create_backup
    res = create_backup()
    if not res.get("ok"):
        raise HTTPException(500, res.get("error", "backup failed"))
    return res


@router.get("/backups")
def get_backups_list() -> List[Dict]:
    from ..backup.backup import list_backups
    return list_backups()


# ---------------- data master (spec §4) ----------------
@router.get("/data/master")
def list_master_datasets() -> List[Dict]:
    db = get_db()
    return db.q("SELECT * FROM master_datasets ORDER BY symbol, timeframe")


@router.post("/data/sync")
def sync_market_data(payload: Dict = Body(default_factory=dict)) -> Dict:
    from ..data.engine import get_data_engine
    de = get_data_engine()
    cfg = get_config()
    sym = payload.get("symbol", cfg.data.symbol)
    tf = payload.get("timeframe")
    force = bool(payload.get("force", False))
    async_mode = bool(payload.get("async", False))

    if async_mode:
        import threading
        def do_sync():
            try:
                if tf and tf.upper() != "ALL":
                    de.sync_master(sym, tf, force_full=force)
                else:
                    de.ingest_default()
            except Exception as e:
                log.error("background sync failed: %s", e)

        threading.Thread(target=do_sync, daemon=True).start()
        return {
            "status": "started",
            "symbol": sym,
            "timeframe": tf or "ALL",
            "message": f"Background synchronization started for {sym}"
        }

    if tf and tf.upper() != "ALL":
        return de.sync_master(sym, tf, force_full=force)
    else:
        return {"results": de.ingest_default()}


# ---------------- logs & events ----------------
@router.get("/logs")
def logs(limit: int = 500, level: Optional[str] = None, category: Optional[str] = None) -> Dict:
    return {"logs": get_logs(limit, level, category)}


@router.get("/logs/export")
def export_technical_log() -> Dict:
    from ..logging_setup import get_full_technical_log_text
    return {"log_text": get_full_technical_log_text()}


@router.get("/pipeline/state")
def get_pipeline_state_endpoint() -> Dict:
    from ..orchestrator.pipeline_state import get_pipeline_state
    return get_pipeline_state().to_dict()


@router.get("/events")
def events(limit: int = 120) -> Dict:
    return {"events": bus.recent_events(limit)}


# ---------------- milestones & workflow ----------------
@router.get("/workflow/milestones")
def get_workflow_milestones() -> Dict:
    from ..orchestrator.milestones import get_milestone_manager
    return get_milestone_manager().compute_route_state()


@router.get("/workflow/task_state")
def get_workflow_task_state() -> Dict[str, Any]:
    from ..orchestrator.stages import get_stage_manager
    return get_stage_manager().get_unified_task_state()


# ---------------- feature tasks & watchdog ----------------
@router.get("/features/tasks")
def list_feature_tasks(limit: int = 50) -> List[Dict]:
    from ..features.tasks import get_feature_task_manager
    return get_feature_task_manager().list_tasks(limit=limit)


@router.get("/features/current_task")
def get_current_feature_task() -> Optional[Dict]:
    from ..features.tasks import get_feature_task_manager
    task = get_feature_task_manager().get_active_task()
    return task.to_dict() if task else None


@router.post("/features/stall_check")
def trigger_stall_check() -> Dict:
    from ..features.tasks import get_feature_task_manager
    stalled = get_feature_task_manager().check_all_stalls()
    return {"checked_at": time.time(), "stalled_count": len(stalled), "stalled_tasks": stalled}


# ---------------- top status row consolidated details ----------------
@router.get("/system/status_row")
def get_system_status_row() -> Dict[str, Any]:
    import socket
    import psutil
    from .. import paths as P
    from ..resources.manager import get_resource_manager
    from ..mt5.monitor import get_connection_monitor
    from ..mt5 import bridge_status
    from ..orchestrator.milestones import get_milestone_manager
    from ..data.engine import get_data_engine

    rm = get_resource_manager()
    mon = get_connection_monitor()
    bs = bridge_status()
    db = get_db()
    lab = get_lab()
    mm = get_milestone_manager()
    res = rm.live_metrics()
    counts = db.count_by_status()

    # Network detection
    try:
        net_stats = psutil.net_if_stats()
        net_addrs = psutil.net_if_addrs()
        active_iface = None
        ip_addr = "127.0.0.1"
        for iface, stat in net_stats.items():
            if stat.isup and not iface.startswith("lo"):
                active_iface = iface
                if iface in net_addrs:
                    for addr in net_addrs[iface]:
                        if addr.family == socket.AF_INET:
                            ip_addr = addr.address
                            break
                break
    except Exception:
        active_iface = "eth0"
        ip_addr = "127.0.0.1"

    # DATA info
    de = get_data_engine()
    all_ds = de.list_datasets()
    data_rows = sum(d.get("rows", 0) for d in all_ds)
    cached_feats = len(list(P.FEATURES_DIR.glob("*.parquet"))) if P.FEATURES_DIR.exists() else 0

    # Honest GPU processing status (never fake utilization)
    gpu_proc = "ACTIVE" if (res["gpu"]["enabled"] and res["gpu"]["available"] and res["gpu"]["utilization_pct"] > 0) else "IDLE"

    route_state = mm.compute_route_state()

    return {
        "wifi": {
            "status": "ONLINE" if active_iface else "CONNECTED",
            "interface": active_iface or "eth0",
            "ip": ip_addr,
            "latency_ms": round(mon.status_details().get("metrics", {}).get("latency_ms", 1.2), 1),
            "state": "Connected to Laboratory Network",
        },
        "mt5": {
            "connected": bs.get("connected", False),
            "is_simulated": bs.get("is_simulated", True),
            "source": "SIMULATOR" if bs.get("is_simulated", True) else "MT5 Terminal",
            "account": bs.get("account", 100001),
            "broker": bs.get("server", "Simulator-Demo"),
            "ping_ms": round(mon.status_details().get("metrics", {}).get("latency_ms", 1.2), 1),
            "feed_status": "FEED ACTIVE" if bs.get("connected") else "FEED PAUSED",
        },
        "cpu": {
            "percent": res["cpu"]["percent"],
            "target_pct": res["cpu"]["target_pct"],
            "physical_cores": res["cpu"]["physical_cores"],
            "logical_processors": res["cpu"]["logical_processors"],
            "effective_workers": res["cpu"]["effective_workers"],
            "active_workers": res["cpu"]["active_workers"],
        },
        "gpu": {
            "enabled": res["gpu"]["enabled"],
            "available": res["gpu"]["available"],
            "name": res["gpu"]["name"],
            "processing_state": gpu_proc,
            "utilization_pct": res["gpu"]["utilization_pct"],
            "vram_used_mb": res["gpu"]["vram_used_mb"],
            "vram_total_mb": res["gpu"]["vram_total_mb"],
        },
        "ram": {
            "used_mb": res["memory"]["used_mb"],
            "total_mb": res["memory"]["total_mb"],
            "percent": res["memory"]["percent"],
            "limit_gb": res["memory"]["limit_gb"],
        },
        "data": {
            "root_path": str(P.DATA_ROOT),
            "dataset_count": len(all_ds),
            "total_rows": data_rows,
            "cached_features_count": cached_feats,
            "reuse_status": "PERSISTENT (REUSE ACTIVE)",
        },
            "db": {
                "path": str(P.DATABASE_DIR / "lab_state.db"),
                "user_version": 3,
                "total_strategies": sum(counts.values()),
                "status": "OPERATIONAL (LINEAGE PRESERVED)",
            },
        "research": {
            "mode": lab.mode,
            "running": lab.running,
            "paused": lab.paused,
            "generation": lab.status().get("generation", 0),
            "active_population": lab.evo.active_count(),
            "target": lab.evo.get_total_node_target(),
        },
        "progress": {
            "milestone": route_state["active_milestone"]["label"],
            "fill_percentage": route_state["fill_percentage"],
            "active_task": route_state["active_milestone"].get("current_task") or "Ready",
        },
    }


# ---------------- Data Management Endpoints (Spec V2.8 Step 4) ----------------
def _dir_size_bytes(p: Path) -> int:
    import os
    if not p.exists():
        return 0
    total = 0
    for root, _, files in os.walk(p):
        for f in files:
            fp = Path(root) / f
            try:
                total += fp.stat().st_size
            except OSError:
                pass
    return total


def _clear_dir_contents(p: Path, remove_subdirs: bool = True) -> int:
    import shutil
    if not p.exists():
        return 0
    count = 0
    for item in p.iterdir():
        try:
            if item.is_file() or item.is_symlink():
                item.unlink()
                count += 1
            elif item.is_dir():
                if remove_subdirs:
                    shutil.rmtree(item)
                    count += 1
                else:
                    count += _clear_dir_contents(item, remove_subdirs=True)
        except Exception as e:
            log.warning("Failed to remove %s: %s", item, e)
    return count


@router.get("/data/management/status")
def data_management_status():
    """Returns data source, timeframe statuses, byte sizes and item counts for Settings Data Management."""
    from ..data.discovery import get_discovery_engine
    de = get_discovery_engine()
    db = get_db()
    rep = de.get_startup_status_report(db)

    xauusd_bytes = _dir_size_bytes(P.MT5_XAUUSD_DIR)
    cache_bytes = _dir_size_bytes(P.CACHE_ROOT) + _dir_size_bytes(P.DATA_DIR / "cache") + _dir_size_bytes(P.DATA_DIR / "features")
    strat_row = db.one("SELECT COUNT(*) c FROM strategies")
    nodes_count = int(strat_row["c"]) if strat_row else 0
    gen_row = db.one("SELECT COUNT(*) c FROM strategies WHERE genome IS NOT NULL")
    genomes_count = int(gen_row["c"]) if gen_row else 0

    return {
        "ok": True,
        "timeframes": rep["data"].get("timeframes", {
            "M1": "MISSING", "M5": "MISSING", "M15": "MISSING", "M30": "MISSING", "H1": "MISSING"
        }),
        "data_source": rep["data"].get("data_source", "NONE"),
        "raw_datasets_count": rep["data"]["raw_datasets"],
        "valid_datasets_count": rep["data"]["valid_datasets"],
        "invalid_datasets_count": rep["data"]["invalid_datasets"],
        "missing_datasets_count": rep["data"]["missing_datasets"],
        "xauusd_size_bytes": xauusd_bytes,
        "cache_size_bytes": cache_bytes,
        "nodes_count": nodes_count,
        "genomes_count": genomes_count,
    }


_CLEAR_LOCK = threading.Lock()

def _run_clear_job(job_name: str, job_type: str, fn, timeout_s: float = 5.0) -> Dict[str, Any]:
    """Execute data clearance asynchronously in background thread with timeout protection and research safety."""
    from ..jobs import get_job_manager
    jm = get_job_manager()
    job = jm.create_job(name=job_name, job_type=job_type, stall_threshold_s=30.0)
    job.start()

    res_box: Dict[str, Any] = {}
    err_box: Dict[str, Any] = {}
    done_event = threading.Event()

    def _worker():
        if not _CLEAR_LOCK.acquire(timeout=10.0):
            err_msg = "Cleanup operation rejected: another clearance is currently running"
            err_box["error"] = err_msg
            job.fail(err_msg)
            done_event.set()
            return

        try:
            # Safely pause active research to avoid file or db lock contention
            from ..orchestrator.lab import get_lab
            lab = get_lab()
            if lab.running and not lab.paused:
                log.info("[DATA MANAGEMENT] Pausing research loop prior to %s", job_name)
                lab.pause()
                time.sleep(0.3)

            # Cancel active feature tasks if any
            try:
                from ..features.tasks import get_feature_task_manager
                get_feature_task_manager().cancel_all_active(f"Cancelled by {job_name}")
            except Exception:
                pass

            # Execute clearance
            res_box["result"] = fn()
            job.complete(meta=res_box.get("result"))
        except Exception as e:
            err_box["error"] = str(e)
            job.fail(str(e))
        finally:
            _CLEAR_LOCK.release()
            done_event.set()

    t = threading.Thread(target=_worker, name=f"clear-{job_type}", daemon=True)
    t.start()

    finished = done_event.wait(timeout=timeout_s)
    if finished:
        if err_box:
            raise HTTPException(500, f"Clear operation failed: {err_box['error']}")
        res = res_box.get("result", {})
        return {
            "ok": True,
            "job_id": job.job_id,
            "status": "completed",
            **res,
        }
    return {
        "ok": True,
        "job_id": job.job_id,
        "status": "processing",
        "message": f"{job_name} running in background",
    }


@router.post("/data/clear/xauusd")
def clear_xauusd_data():
    """Deletes authoritative raw XAUUSD data only. Requires modal confirmation."""
    def _action():
        from ..activity import activity
        from ..data.discovery import get_discovery_engine
        db = get_db()
        deleted = 0

        deleted += _clear_dir_contents(P.MT5_XAUUSD_DIR, remove_subdirs=True)
        for d in (P.MT5_RAW_DIR, P.MT5_NORMALIZED_DIR):
            if d.exists():
                for f in d.glob("*XAUUSD*"):
                    try:
                        f.unlink()
                        deleted += 1
                    except Exception:
                        pass

        db.x("DELETE FROM datasets WHERE symbol='XAUUSD'")
        db.x("DELETE FROM master_datasets WHERE symbol='XAUUSD'")
        P.ensure_layout()
        de = get_discovery_engine()
        de.invalidate_startup_status_cache()
        de.discover_all(emit_logs=False)

        log.info("[DATA MANAGEMENT] Cleared XAUUSD raw data (%d files deleted)", deleted)
        activity.info("DATA", f"Cleared XAUUSD raw data ({deleted} items deleted)")
        return {"message": "Authoritative XAUUSD raw data cleared", "deleted_files": deleted}

    return _run_clear_job("Clear XAUUSD Raw Data", "clear_xauusd", _action)


@router.post("/data/clear/cache")
def clear_cache():
    """Deletes derived cache: features, temp files, results cache, manifests cache. Leaves raw data intact."""
    def _action():
        from ..activity import activity
        from ..data.discovery import get_discovery_engine
        deleted = 0
        if P.CACHE_ROOT.exists():
            deleted += _clear_dir_contents(P.CACHE_ROOT, remove_subdirs=True)
        for sub in ("FEATURES", "NODES", "GENOMES", "BACKTESTS", "RESULTS", "CHECKPOINTS", "MANIFESTS"):
            d = P.CACHE_ROOT / sub
            if d.exists():
                deleted += _clear_dir_contents(d, remove_subdirs=True)
        deleted += _clear_dir_contents(P.DATA_DIR / "cache", remove_subdirs=True)
        deleted += _clear_dir_contents(P.DATA_DIR / "features", remove_subdirs=True)
        P.ensure_layout()
        get_discovery_engine().invalidate_startup_status_cache()

        log.info("[DATA MANAGEMENT] Cleared derived CACHE (%d files deleted)", deleted)
        activity.info("CACHE", f"Cleared derived CACHE ({deleted} items deleted)")
        return {"message": "Derived cache cleared", "deleted_files": deleted}

    return _run_clear_job("Clear Derived Cache", "clear_cache", _action)


@router.post("/data/clear/nodes")
def clear_nodes():
    """Deletes persisted research node records / artifacts. Leaves raw market data intact."""
    def _action():
        from ..activity import activity
        from ..data.discovery import get_discovery_engine
        from ..evolution.engine import get_evo_engine
        db = get_db()
        strat_row = db.one("SELECT COUNT(*) c FROM strategies")
        deleted_nodes = int(strat_row["c"]) if strat_row else 0

        for tbl in ("paper_trades", "matrices", "validations", "backtests", "research_shortlist", "strategies", "generation_stats"):
            try:
                db.x(f"DELETE FROM {tbl}")
            except Exception:
                pass

        del_files = _clear_dir_contents(P.NODES_DIR, remove_subdirs=True)
        del_files += _clear_dir_contents(P.CACHE_ROOT / "NODES", remove_subdirs=True)
        P.ensure_layout()
        get_discovery_engine().invalidate_startup_status_cache()
        try:
            get_evo_engine()._cached_node_state = None
        except Exception:
            pass

        log.info("[DATA MANAGEMENT] Cleared research nodes (%d nodes, %d files)", deleted_nodes, del_files)
        activity.info("RESEARCH", f"Cleared {deleted_nodes} research node records (raw market data intact)")
        return {"message": "Research node records and artifacts cleared", "deleted_nodes": deleted_nodes}

    return _run_clear_job("Clear Research Nodes", "clear_nodes", _action)


@router.post("/data/clear/genomes")
def clear_genomes():
    """Deletes persisted genome records. Leaves raw market data intact."""
    def _action():
        from ..activity import activity
        from ..data.discovery import get_discovery_engine
        del_files = _clear_dir_contents(P.GENOMES_DIR, remove_subdirs=True)
        del_files += _clear_dir_contents(P.CACHE_ROOT / "GENOMES", remove_subdirs=True)
        gm_path = P.MANIFESTS_DIR / "genomes.json"
        if gm_path.exists():
            try:
                gm_path.unlink()
                del_files += 1
            except Exception:
                pass
        P.ensure_layout()
        get_discovery_engine().invalidate_startup_status_cache()

        log.info("[DATA MANAGEMENT] Cleared genomes (%d files deleted)", del_files)
        activity.info("RESEARCH", f"Cleared genomes ({del_files} files deleted, raw market data intact)")
        return {"message": "Genomes cleared", "deleted_files": del_files}

    return _run_clear_job("Clear Genomes", "clear_genomes", _action)


@router.post("/data/clear/all")
def clear_all_data(payload: Dict[str, Any] = Body(...)):
    """High-risk nuclear reset: deletes all market data, cache, and research state.
    Requires explicit confirmation: user must type 'CLEAR ALL DATA' or 'DELETE THE DATA'.
    """
    confirm_text = payload.get("confirm", "").strip()
    if confirm_text not in ("CLEAR ALL DATA", "DELETE THE DATA"):
        raise HTTPException(
            status_code=400,
            detail="Confirmation mismatch. You must explicitly type 'CLEAR ALL DATA' or 'DELETE THE DATA' to proceed."
        )

    def _action():
        from ..activity import activity
        from ..data.discovery import get_discovery_engine
        from ..evolution.engine import get_evo_engine
        db = get_db()

        # 1. Clear XAUUSD data
        _clear_dir_contents(P.MT5_XAUUSD_DIR, remove_subdirs=True)
        for d in (P.MT5_RAW_DIR, P.MT5_NORMALIZED_DIR):
            if d.exists():
                for f in d.glob("*"):
                    try:
                        f.unlink()
                    except Exception:
                        pass
        db.x("DELETE FROM datasets")
        db.x("DELETE FROM master_datasets")

        # 2. Clear CACHE
        if P.CACHE_ROOT.exists():
            _clear_dir_contents(P.CACHE_ROOT, remove_subdirs=True)
        for sub in ("FEATURES", "NODES", "GENOMES", "BACKTESTS", "RESULTS", "CHECKPOINTS", "MANIFESTS"):
            d = P.CACHE_ROOT / sub
            if d.exists():
                _clear_dir_contents(d, remove_subdirs=True)
        _clear_dir_contents(P.DATA_DIR / "cache", remove_subdirs=True)
        _clear_dir_contents(P.DATA_DIR / "features", remove_subdirs=True)

        # 3. Clear nodes, research, genomes
        for tbl in ("paper_trades", "matrices", "validations", "backtests", "research_shortlist", "strategies", "generation_stats"):
            try:
                db.x(f"DELETE FROM {tbl}")
            except Exception:
                pass
        _clear_dir_contents(P.NODES_DIR, remove_subdirs=True)
        _clear_dir_contents(P.GENOMES_DIR, remove_subdirs=True)
        _clear_dir_contents(P.MANIFESTS_DIR, remove_subdirs=True)

        P.ensure_layout()
        de = get_discovery_engine()
        de.invalidate_startup_status_cache()
        de.discover_all(emit_logs=False)
        try:
            get_evo_engine()._cached_node_state = None
        except Exception:
            pass

        log.info("[DATA MANAGEMENT] NUCLEAR RESET: All market data, cache, and research state cleared.")
        activity.warning("SYSTEM", "NUCLEAR RESET: All market data, cache, and research state cleared.")
        return {"message": "All data, cache, and research state successfully cleared"}

    return _run_clear_job("Nuclear Reset (Clear All Data)", "clear_all_data", _action)

