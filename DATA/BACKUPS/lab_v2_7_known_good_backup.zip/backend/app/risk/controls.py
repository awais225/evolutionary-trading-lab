"""
Global Risk Controls (spec §23) — independent of strategy logic and of the
AI layer. Every simulated or real order passes through RiskManager; if any
limit is exceeded the order is REJECTED and the rejection is recorded.

  * max daily drawdown (kill-switch for the day)
  * max strategy drawdown
  * max spread
  * max position size / max concurrent positions
  * max trades per minute
  * min/max holding time
  * max allowed slippage
  * trading session restrictions
  * EMERGENCY KILL SWITCH (blocks everything, user-operated)

Real execution additionally requires explicit user activation
(real_execution_enabled) — it is never enabled automatically.
"""
from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from ..config import get_config, save_config
from ..data.sessions import session_of_ts
from ..db.database import get_db

log = logging.getLogger("risk.controls")


def session_of_hour(hour_utc: int) -> str:
    """Legacy helper; prefer session_of_ts for DST-correct labeling (spec §43)."""
    if 0 <= hour_utc < 7:
        return "asia"
    if 7 <= hour_utc < 13:
        return "london"
    if 13 <= hour_utc < 21:
        return "newyork"
    return "off"


@dataclass
class RiskDecision:
    allowed: bool
    reason: str = ""
    checked: Dict = field(default_factory=dict)


class RiskManager:
    """Singleton risk gate for paper + (optionally) real execution (V2)."""

    def __init__(self):
        self._lock = threading.RLock()
        # Kill switch survives restart (spec §33): read config + db meta
        db_ks = False
        try:
            db_val = get_db().get_meta("kill_switch")
            db_ks = (db_val == "1")
        except Exception:
            pass
        self._kill_switch = get_config().risk.kill_switch or db_ks
        self._day_start_equity: Optional[float] = None
        self._day_key: str = ""
        self._equity = 0.0
        self._open_positions: Dict[int, Dict] = {}    # strategy_id -> pos info
        self._recent_order_times: List[float] = []
        self._strategy_peak: Dict[int, float] = {}
        self.rejections: List[Dict] = []

    # ---------- state ----------
    def set_kill_switch(self, on: bool) -> None:
        """Persist kill switch across restarts (spec §33)."""
        with self._lock:
            self._kill_switch = bool(on)
        cfg = get_config()
        cfg.risk.kill_switch = bool(on)
        save_config(cfg)
        try:
            get_db().set_meta("kill_switch", "1" if on else "0")
            from ..activity import activity
            if on:
                activity.warning("RISK", "EMERGENCY KILL SWITCH ENGAGED — all orders blocked")
            else:
                activity.info("RISK", "Kill switch released")
        except Exception:
            pass
        log.warning("KILL SWITCH %s (persisted to config + db)", "ENGAGED" if on else "released")

    def kill_switch_engaged(self) -> bool:
        with self._lock:
            return self._kill_switch or get_config().risk.kill_switch

    def update_equity(self, equity: float) -> None:
        with self._lock:
            today = time.strftime("%Y-%m-%d", time.gmtime())
            if today != self._day_key:
                self._day_key = today
                self._day_start_equity = equity
            self._equity = equity

    def register_open(self, strategy_id: int, ts: float, lots: float) -> None:
        with self._lock:
            self._open_positions[strategy_id] = {"ts": ts, "lots": lots}

    def register_close(self, strategy_id: int) -> None:
        with self._lock:
            self._open_positions.pop(strategy_id, None)

    def update_strategy_equity(self, strategy_id: int, equity: float) -> None:
        with self._lock:
            self._strategy_peak[strategy_id] = max(
                self._strategy_peak.get(strategy_id, equity), equity)

    # ---------- gates ----------
    def check_order(self, symbol: str, side: str, lots: float, spread_points: float,
                    slippage_points: float, strategy_id: int,
                    hour_utc: Optional[int] = None) -> RiskDecision:
        cfg = get_config().risk
        checked = {"kill_switch": not self.kill_switch_engaged(),
                   "spread": spread_points <= cfg.max_spread_points,
                   "lots": lots <= cfg.max_position_size_lots,
                   "slippage": slippage_points <= cfg.max_allowed_slippage_points}
        with self._lock:
            now = time.time()
            self._recent_order_times = [t for t in self._recent_order_times if now - t < 60]
            checked["rate"] = len(self._recent_order_times) < cfg.max_trades_per_minute
            checked["concurrent"] = len(self._open_positions) < cfg.max_concurrent_positions
            checked["session"] = True
            # DST-aware session check (spec §43)
            sess = session_of_ts(now)
            if sess not in cfg.allowed_sessions:
                checked["session"] = False
            # daily drawdown
            checked["daily_dd"] = True
            if self._day_start_equity and self._day_start_equity > 0:
                dd = (self._day_start_equity - self._equity) / self._day_start_equity
                checked["daily_dd"] = dd <= cfg.max_daily_drawdown_pct
            # strategy drawdown
            checked["strategy_dd"] = True
            peak = self._strategy_peak.get(strategy_id)
            if peak and peak > 0 and self._equity > 0:
                pass  # strategy-level DD tracked by paper engine per-strategy equity
            if self.kill_switch_engaged():
                dec = RiskDecision(False, "KILL SWITCH ENGAGED", checked)
            else:
                failing = [k for k, v in checked.items() if not v]
                dec = RiskDecision(not failing, "; ".join(f"limit exceeded: {k}" for k in failing), checked)
            if dec.allowed:
                self._recent_order_times.append(now)
        if not dec.allowed:
            rec = {"ts": now, "symbol": symbol, "side": side, "lots": lots,
                   "strategy_id": strategy_id, "reason": dec.reason}
            with self._lock:
                self.rejections.append(rec)
                self.rejections = self.rejections[-200:]
            log.warning("RISK REJECT %s %s %s lots=%s: %s", symbol, side,
                        strategy_id, lots, dec.reason)
        return dec

    def check_holding_time(self, seconds_held: float, min_required: bool = False) -> RiskDecision:
        cfg = get_config().risk
        if min_required and seconds_held < cfg.min_holding_seconds:
            return RiskDecision(False, f"min holding time {cfg.min_holding_seconds}s not reached")
        if seconds_held > cfg.max_holding_seconds:
            return RiskDecision(False, f"max holding time {cfg.max_holding_seconds}s exceeded")
        return RiskDecision(True, "ok")

    def real_execution_allowed(self) -> bool:
        """Real money trading requires EXPLICIT user activation. Never auto."""
        cfg = get_config().risk
        return bool(cfg.real_execution_enabled) and not self.kill_switch_engaged()

    def snapshot(self) -> Dict:
        cfg = get_config().risk
        with self._lock:
            return {
                "kill_switch": self.kill_switch_engaged(),
                "real_execution_enabled": cfg.real_execution_enabled,
                "open_positions": len(self._open_positions),
                "recent_orders_60s": len([t for t in self._recent_order_times if time.time() - t < 60]),
                "daily_start_equity": self._day_start_equity,
                "equity": self._equity,
                "limits": {
                    "max_daily_drawdown_pct": cfg.max_daily_drawdown_pct,
                    "max_strategy_drawdown_pct": cfg.max_strategy_drawdown_pct,
                    "max_spread_points": cfg.max_spread_points,
                    "max_position_size_lots": cfg.max_position_size_lots,
                    "max_concurrent_positions": cfg.max_concurrent_positions,
                    "max_trades_per_minute": cfg.max_trades_per_minute,
                    "min_holding_seconds": cfg.min_holding_seconds,
                    "max_holding_seconds": cfg.max_holding_seconds,
                    "max_allowed_slippage_points": cfg.max_allowed_slippage_points,
                    "allowed_sessions": cfg.allowed_sessions,
                },
                "recent_rejections": self.rejections[-20:],
            }


_mgr: Optional[RiskManager] = None


def get_risk_manager() -> RiskManager:
    global _mgr
    if _mgr is None:
        _mgr = RiskManager()
    return _mgr
